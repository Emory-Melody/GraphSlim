from graphslim.models import get_model_class
import copy

import numpy as np
import torch
from sklearn.cluster import KMeans

from graphslim.dataset.utils import save_reduced
from graphslim.evaluation.utils import verbose_time_memory
from graphslim.models import GCN
from graphslim.utils import one_hot, gcn_normalize_adj
from graphslim.reduction.cluster_ops import fitted_labels, sparse_membership


def _virtual_adjacency(representatives, propagated, source_dtype):
    """Least squares with rank tolerance appropriate to the input embeddings.

    Sparse aggregation promotes float32 embeddings to float64, but does not
    create additional significant digits. Do not invert that float32 noise.

    :param representatives: Representative embedding matrix ``P`` with one row
        per virtual node.
    :param propagated: Aggregated propagated embeddings ``Q`` with the same
        shape as ``P``.
    :param source_dtype: NumPy floating dtype of the original embeddings, used
        to set the pseudoinverse rank cutoff.
    :returns: Float64 virtual adjacency ``Q @ pinv(P)``.
    :raises ValueError: If either embedding matrix contains non-finite values.
    """
    if not np.isfinite(representatives).all() or not np.isfinite(propagated).all():
        raise ValueError("VNG least-squares inputs must be finite")
    rcond = max(representatives.shape) * np.finfo(source_dtype).eps
    return np.asarray(propagated, dtype=np.float64) @ np.linalg.pinv(
        np.asarray(representatives, dtype=np.float64), rcond=rcond
    )


class VNG:
    """
    A class that implements Virtual Node Graph (VNG) reduction for coarsening graphs.
    Refer to paper "Serving Graph Compression for Graph Neural Networks" https://openreview.net/forum?id=T-qVtA3pAxG.

    Parameters
    ----------
    setting : str
        Configuration setting.
    data : object
        Data object containing the graph and feature information.
    args : object
        Arguments containing various settings for the coarsening process.
    **kwargs : dict, optional
        Additional keyword arguments.
    """

    def __init__(self, setting, data, args, **kwargs):
        """Initialize VNG and its configuration.

        :param setting: Graph learning setting: ``trans`` for the full graph or ``ind`` for split subgraphs.
        :param data: Graph data containing features, adjacency, labels, and split indices.
        :param args: Configuration namespace containing the options used by this operation.
        :param kwargs: Additional keyword options passed to the underlying implementation.
        """
        self.setting = setting
        self.args = args
        self.device = args.device
        # Pass data for initialization

    @verbose_time_memory
    def reduce(self, data, verbose=False):
        """
        Reduces the data by applying Virtual Node Graph (VNG) method.

        Parameters
        ----------
        data : object
            The data to be reduced.
        verbose : bool, optional
            If True, prints verbose output. Defaults to False.

        Returns
        -------
        object
            The reduced data with synthesized adjacency, features, and labels.
        """
        args = self.args
        setting = self.setting
        operator_profile = getattr(args, "vng_normalized_operator", False)
        if operator_profile and args.condense_model != "GCN":
            raise ValueError("The VNG normalized-operator profile requires a GCN teacher")

        if args.setting == "trans":
            model = get_model_class(args.condense_model)(
                data.feat_full.shape[1], args.hidden, data.nclass, args
            ).to(self.device)
            model.fit_with_val(
                data,
                train_iters=args.eval_epochs,
                normadj=True,
                verbose=verbose,
                setting=args.setting,
                reduced=False,
            )
            embeds, _ = model.predict(data.feat_full, data.adj_full, output_layer_features=True)
            if isinstance(embeds, torch.Tensor):
                embeds = [embeds]
            if operator_profile:
                # Paper Eq. (7): features BEFORE each propagation, not logits.
                embeds = [data.feat_full, *embeds[:-1]]
            embeds = [embed[data.train_mask] for embed in embeds]
            labels = one_hot(data.labels_train, data.nclass)

            coarsen_edge, coarsen_features, coarsen_labels = self.vng(
                data.feat_full[data.train_mask], embeds, data.adj_train, labels
            )

        else:
            model = get_model_class(args.condense_model)(
                data.feat_full.shape[1], args.hidden, data.nclass, args
            ).to(self.device)
            model.fit_with_val(
                data,
                train_iters=args.eval_epochs,
                normadj=True,
                verbose=verbose,
                setting=args.setting,
                reduced=False,
                reindex=True,
            )
            model.eval()
            embeds, _ = model.predict(data.feat_train, data.adj_train, output_layer_features=True)
            if isinstance(embeds, torch.Tensor):
                embeds = [embeds]
            if operator_profile:
                embeds = [data.feat_train, *embeds[:-1]]
            embeds = [embed for embed in embeds]
            labels = one_hot(data.labels_train, data.nclass)

            coarsen_edge, coarsen_features, coarsen_labels = self.vng(
                data.feat_full[data.train_mask], embeds, data.adj_train, labels
            )

        data.adj_syn, data.feat_syn, data.labels_syn = (
            coarsen_edge,
            coarsen_features,
            coarsen_labels,
        )

        save_reduced(coarsen_edge, coarsen_features, coarsen_labels, args)

        return data

    def vng(self, X_tr_0, embeds, adj, labels, verbose=False):
        """
        Virtual Node Graph (VNG) method to coarsen the graph.

        Parameters
        ----------
        X_tr_0 : torch.Tensor
            Original training-node features with shape ``(num_train, num_features)``.
        embeds : list of tensors
            List of embeddings.
        adj : scipy.sparse matrix
            Training-node adjacency in the same node order as the features.
        labels : tensor
            One-hot encoded labels.
        verbose : bool, optional
            If True, prints verbose output. Defaults to False.

        Returns
        -------
        tuple
            A tuple containing:

            - coarsen_edge : tensor
                Coarsened adjacency matrix.
            - coarsen_features : tensor
                Coarsened features.
            - coarsen_labels : tensor
                Coarsened labels.
        """
        X_tr_head = torch.concat([embed.detach().cpu() for embed in embeds], dim=1).numpy()
        self.last_embedding_width = X_tr_head.shape[1]
        X_tr_0 = X_tr_0.cpu().detach().numpy()
        A_tr = adj
        if getattr(self.args, "vng_normalized_operator", False):
            # The paper's A is the GNN propagation operator. The learned virtual
            # operator can be signed, so it must not receive degree normalization.
            A_tr = gcn_normalize_adj(A_tr.astype(np.float32))

        column_sum = np.sum(A_tr, axis=0)
        column_sum = np.asarray(column_sum).reshape(-1)
        column_sum[column_sum == 0] = 1

        num_coarsen_node = int(self.args.reduction_rate * X_tr_0.shape[0])

        # PROPAGATION FROM VIRTUAL REPRESENTATIVE NODES TO TESTING NODES
        kmeans = KMeans(n_clusters=num_coarsen_node, random_state=2024, n_init=1)
        assignments = fitted_labels(kmeans, X_tr_head, sample_weight=column_sum)
        E = sparse_membership(assignments, num_coarsen_node, column_sum, normalize=True)
        M = sparse_membership(assignments, num_coarsen_node)

        X_vr_0 = E @ X_tr_0

        if verbose:
            print("E: ", E.shape)
            print("X_vr_0: ", X_vr_0.shape)

        # PROPAGATION BETWEEN VIRTUAL REPRESENTATIVE NODES
        P = E @ X_tr_head
        Q = E @ A_tr @ X_tr_head
        if getattr(self.args, "vng_normalized_operator", False):
            # Aggregation does not create precision beyond the learned inputs.
            A_vr = _virtual_adjacency(P, Q, X_tr_head.dtype)
        else:
            A_vr = Q @ np.linalg.pinv(P)

        if verbose:
            print("P: ", P.shape)
            print("Q: ", Q.shape)
            print("SVD relative cutoff: ", max(P.shape) * np.finfo(X_tr_head.dtype).eps)
            print("A_vr Sparsity", len(np.nonzero(A_vr)[0]) / A_vr.shape[0] ** 2)
            print("A_vr: ", A_vr.shape)

        coarsen_features = torch.from_numpy(X_vr_0).float()
        coarsen_edge = torch.from_numpy(A_vr).float()
        coarsen_labels = torch.argmax(torch.FloatTensor(M.dot(labels)), dim=1).long()

        return coarsen_edge, coarsen_features, coarsen_labels
