import json
import os.path as osp
import os
import pickle

import numpy as np
import scipy.sparse as sp
import torch
import torch.nn as nn
import torch.nn.functional as F
from ogb.nodeproppred import PygNodePropPredDataset
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from torch_geometric.datasets import (
    Planetoid,
    Coauthor,
    CitationFull,
    Amazon,
    Flickr,
    Reddit2,
    HeterophilousGraphDataset,
)
from torch_geometric.loader import NeighborSampler
from torch_geometric.utils import to_undirected, add_self_loops
from torch_sparse import SparseTensor
import shutil
from contextlib import nullcontext

from graphslim.dataset.convertor import ei2csr, csr2ei, from_dgl
from graphslim.dataset.utils import splits
from graphslim.utils import index_to_mask, to_tensor

try:
    from torch_geometric.data.data import DataEdgeAttr, DataTensorAttr  # type: ignore
except ImportError:
    DataEdgeAttr = None  # type: ignore
    DataTensorAttr = None  # type: ignore
try:
    from torch_geometric.data.storage import GlobalStorage  # type: ignore
except ImportError:
    GlobalStorage = None  # type: ignore
try:
    import torch.serialization as torch_serialization
except ImportError:
    torch_serialization = None


def ogb_cache_context():
    """Allow only required PyG storage classes when loading compatible OGB caches.

    :returns: PyTorch safe-globals context manager, or a no-op context when unavailable.
    """
    safe_globals = getattr(torch_serialization, "safe_globals", None)
    classes = [
        value for value in (DataEdgeAttr, DataTensorAttr, GlobalStorage) if value is not None
    ]
    return safe_globals(classes) if callable(safe_globals) else nullcontext()


def get_dataset(name="cora", args=None, load_path="./data"):
    """Load a supported node classification dataset and construct transductive and inductive views.

    Dataset names ignore case, hyphens, and underscores. Existing official splits
    are retained; otherwise ``args.split`` controls classwise splitting.

    :param name: Supported dataset name. Defaults to ``'cora'``.
    :param args: Configuration with ``split``, ``pre_norm``, and dataset-specific options. Defaults to ``None``.
    :param load_path: Root directory for downloaded and cached dataset files. Defaults to ``'./data'``.
    :returns: ``TransAndInd`` data wrapper with features, labels, adjacencies, and split indices.
    """
    path = osp.join(load_path)
    # Create a dictionary that maps standard names to normalized names
    standard_names = [
        "flickr",
        "reddit",
        "dblp",
        "cora_ml",
        "physics",
        "cs",
        "cora",
        "citeseer",
        "pubmed",
        "photo",
        "computers",
        "ogbn-products",
        "ogbn-proteins",
        "ogbn-papers100m",
        "ogbn-arxiv",
        "roman-empire",
        "amazon-ratings",
        "yelp",
        "amazon",
    ]
    normalized_names = [name.lower().replace("-", "").replace("_", "") for name in standard_names]
    name_dict = dict(zip(normalized_names, standard_names))

    # Normalize the name input
    normalized_name = name.lower().replace("-", "").replace("_", "")

    if normalized_name in name_dict:
        name = name_dict[normalized_name]  # Transfer to standard name
        if name in ["flickr"]:
            dataset = Flickr(root=path + "/flickr")
        elif name in ["reddit"]:
            dataset = Reddit2(root=path + "/reddit")
        elif name in ["dblp", "cora_ml", "cora_full", "citeseer_full"]:
            dataset = CitationFull(root=path, name=name)
        elif name in ["physics", "cs"]:
            dataset = Coauthor(root=path, name=name)
        elif name in ["cora", "citeseer", "pubmed"]:
            dataset = Planetoid(root=path, name=name)
        elif name in ["photo", "computers"]:
            dataset = Amazon(root=path, name=name)
        elif name in ["ogbn-arxiv"]:
            dataset = DataGraphSAINT(root=path, dataset=name)
            dataset.num_classes = 40
        elif name in ["ogbn-products", "ogbn-proteins", "ogbn-papers100m"]:
            with ogb_cache_context():
                dataset = PygNodePropPredDataset(name, root=path)
        elif name in ["roman-empire", "amazon-ratings"]:
            dataset = HeterophilousGraphDataset(root=path, name=name)
        elif name in ["yelp", "amazon"]:
            try:
                from dgl.data import FraudDataset
            except ImportError as exc:
                raise ImportError("Yelp/Amazon require the optional graphslim[dgl] extra.") from exc
            # dataset = pickle.load(open(f'{path}/{args.dataset}.dat', 'rb'))
            # dataset.num_classes = 2
            dataset = FraudDataset(name, raw_dir=path)
            dataset = from_dgl(dataset[0], name=name, hetero=False)  # dgl2pyg
    else:
        raise ValueError("Dataset name not recognized.")

    try:
        data = dataset[0]

    except:
        data = dataset

    if name in ["ogbn-products", "ogbn-proteins", "ogbn-papers100m"]:
        official = dataset.get_idx_split()
        for key, source in (("train", "train"), ("val", "valid"), ("test", "test")):
            setattr(data, f"{key}_mask", index_to_mask(official[source], data.num_nodes))
        data.y = data.y.squeeze(-1)
    if name in ["roman-empire", "amazon-ratings"]:
        split_id = getattr(args, "dataset_split_id", 0)
        for key in ("train", "val", "test"):
            masks = getattr(data, f"{key}_mask")
            if masks.ndim != 2 or not 0 <= split_id < masks.shape[1]:
                raise ValueError(f"Invalid official split ID {split_id} for {name}")
            setattr(data, f"{key}_mask", masks[:, split_id].clone())

    # pyg2TransAndInd: preserve provided splits, create only absent splits.
    data = splits(data, args.split)

    data = TransAndInd(data, name, args.pre_norm)
    if name in ["roman-empire", "amazon-ratings"]:
        data.split_provenance = {"source": "official", "split_id": split_id}
    elif name in ["ogbn-products", "ogbn-proteins", "ogbn-papers100m"]:
        data.split_provenance = {"source": "ogb.get_idx_split"}
    elif name in ["photo", "computers"]:
        data.split_provenance = {"source": "package.classwise", "split": args.split}

    try:
        data.nclass = dataset.num_classes
    except:
        data.nclass = data.num_classes

    print("train nodes num:", sum(data.train_mask).item())
    print("val nodes num:", sum(data.val_mask).item())
    print("test nodes num:", sum(data.test_mask).item())
    print("total nodes num:", data.x.shape[0])
    return data


class TransAndInd:
    """Shared graph wrapper exposing full-graph and split-local learning views.
    """
    def __init__(self, data, dataset, norm=True):
        """Initialize TransAndInd and its configuration.

        :param data: Graph data containing features, adjacency, labels, and split indices.
        :param dataset: Dataset name or dataset collection, as required by this operation.
        :param norm: Whether to apply the wrapper feature normalization during initialization. Defaults to ``True``.
        """
        self.class_dict = (
            None  # sample the training data per class when initializing synthetic graph
        )
        self.samplers = None
        self.class_dict2 = None  # sample from the same class when training
        self.sparse_adj = None
        self.adj_full = None
        self.feat_full = None
        self.labels_full = None
        self.num_nodes = data.num_nodes
        self.train_mask, self.val_mask, self.test_mask = (
            data.train_mask,
            data.val_mask,
            data.test_mask,
        )
        self.pyg_saint(data)
        if dataset in ["flickr", "reddit", "ogbn-arxiv"]:
            self.edge_index = to_undirected(self.edge_index, self.num_nodes)
            feat_train = self.x[data.idx_train]
            scaler = StandardScaler()
            scaler.fit(feat_train)
            self.feat_full = scaler.transform(self.x)
            self.feat_full = torch.from_numpy(self.feat_full).float()
        if norm and dataset in ["cora", "citeseer", "pubmed"]:
            self.feat_full = F.normalize(self.feat_full, p=1, dim=1)
        self.idx_train, self.idx_val, self.idx_test = data.idx_train, data.idx_val, data.idx_test
        # self.nclass = max(self.labels_full).item() + 1

        self.adj_train = self.adj_full[np.ix_(self.idx_train, self.idx_train)]
        self.adj_val = self.adj_full[np.ix_(self.idx_val, self.idx_val)]
        self.adj_test = self.adj_full[np.ix_(self.idx_test, self.idx_test)]

        self.labels_train = self.labels_full[self.idx_train]
        self.labels_val = self.labels_full[self.idx_val]
        self.labels_test = self.labels_full[self.idx_test]

        self.feat_train = self.feat_full[self.idx_train]
        self.feat_val = self.feat_full[self.idx_val]
        self.feat_test = self.feat_full[self.idx_test]

    def to(self, device):
        """Move direct tensor and torch_sparse attributes to a selected device in place.

        :param device: Target PyTorch device, such as ``cpu`` or ``cuda:0``.
        :returns: This graph wrapper.
        """
        self.feat_full = self.feat_full.to(device)
        self.labels_full = self.labels_full.to(device)
        self.x = self.x.to(device)
        self.y = self.y.to(device)
        self.edge_index = self.edge_index.to(device)

        self.feat_train = self.feat_train.to(device)
        self.feat_val = self.feat_val.to(device)
        self.feat_test = self.feat_test.to(device)

        # self.labels_train = self.labels_train.to(device)
        # self.labels_val = self.labels_val.to(device)
        # self.labels_test = self.labels_test.to(device)

        return self

    def pyg_saint(self, data):
        # reference type
        # pyg format use x,y,edge_index
        """Populate shared full-graph attributes from PyG or GraphSAINT-style inputs.

        :param data: Graph data containing features, adjacency, labels, and split indices.
        :returns: The original data object; normalized attribute aliases are stored on this wrapper.
        """
        if hasattr(data, "x"):
            self.x = data.x
            self.y = data.y
            self.feat_full = data.x
            self.labels_full = data.y
            self.adj_full = ei2csr(data.edge_index, data.x.shape[0])
            self.edge_index = data.edge_index
            self.sparse_adj = SparseTensor.from_edge_index(data.edge_index)
        # saint format use feat,labels,adj
        elif hasattr(data, "feat_full"):
            self.adj_full = data.adj_full
            self.feat_full = data.feat_full
            self.labels_full = data.labels_full
            self.edge_index = csr2ei(data.adj_full)
            self.sparse_adj = SparseTensor.from_edge_index(self.edge_index)
            self.x = data.feat_full
            self.y = data.labels_full
        return data

    def retrieve_class(self, c, num=256):
        # change the initialization strategy here
        """Sample training-subgraph positions belonging to one class.

        :param c: Class identifier.
        :param num: Maximum number of nodes to sample. Defaults to ``256``.
        :returns: Randomly permuted NumPy indices, truncated to the requested count.
        """
        if self.class_dict is None:
            self.class_dict = {}
            for i in range(self.nclass):
                self.class_dict["class_%s" % i] = self.labels_train == i
        idx = np.arange(len(self.labels_train))
        idx = idx[self.class_dict["class_%s" % c]]
        return np.random.permutation(idx)[:num]

    def retrieve_class_sampler(self, c, adj, args, num=256):
        """Sample a class-specific neighbor batch using the configured GNN depth.

        :param c: Class identifier.
        :param adj: Graph adjacency; rows and columns refer to the same node ordering as the features.
        :param args: Configuration namespace containing the options used by this operation.
        :param num: Maximum number of nodes to sample. Defaults to ``256``.
        :returns: NeighborSampler output ``(batch_size, node_ids, adjacency_blocks)``.
        """
        if self.class_dict2 is None:
            self.class_dict2 = {}
            for i in range(self.nclass):
                if args.setting == "trans":
                    idx = self.idx_train[self.labels_train == i]
                else:
                    idx = np.arange(len(self.labels_train))[self.labels_train == i]
                self.class_dict2[i] = idx

        if args.nlayers == 1:
            sizes = [15]
        if args.nlayers == 2:
            if args.dataset in ["reddit", "flickr"]:
                sizes = [15, 8]
            else:
                sizes = [10, 5]
            # sizes = [-1, -1]
        if args.nlayers == 3:
            sizes = [15, 10, 5]
        if args.nlayers == 4:
            sizes = [15, 10, 5, 5]
        if args.nlayers == 5:
            sizes = [15, 10, 5, 5, 5]

        if self.samplers is None:
            self.samplers = []
            for i in range(self.nclass):
                node_idx = torch.LongTensor(self.class_dict2[i])
                self.samplers.append(
                    NeighborSampler(
                        adj,
                        node_idx=node_idx,
                        sizes=sizes,
                        batch_size=num,
                        num_workers=8,
                        return_e_id=False,
                        num_nodes=adj.size(0),
                        shuffle=True,
                    )
                )
        batch = np.random.permutation(self.class_dict2[c])[:num]
        out = self.samplers[c].sample(batch.astype(np.int64))
        return out

    def reset(self):
        """Clear cached class masks and neighbor samplers.
        """
        self.samplers = None
        self.class_dict2 = None
        self.labels_syn, self.feat_syn, self.adj_syn = None, None, None


class LargeDataLoader(nn.Module):
    """Partitioned feature and adjacency loader for large-graph kernel condensation.
    """
    def __init__(
        self, name="Flickr", split="train", batch_size=200, split_method="kmeans", data=None
    ):
        """Initialize LargeDataLoader and its configuration.

        :param name: Dataset name or dataset collection, as required by this operation. Defaults to ``'Flickr'``.
        :param split: Dataset split to load, such as ``train``, ``val``, or ``test``. Defaults to ``'train'``.
        :param batch_size: Approximate target number of nodes per partition; k-means partition sizes may differ. Defaults to ``200``.
        :param split_method: Partitioning method used to assign nodes to batches. Defaults to ``'kmeans'``.
        :param data: Graph data containing features, adjacency, labels, and split indices. Defaults to ``None``.
        """
        super(LargeDataLoader, self).__init__()
        if batch_size <= 0:
            raise ValueError("batch_size must be positive")
        if data is not None:
            # Reducers must use the caller's graph and split, including supplied
            # subgraphs and perturbations, rather than reopen a named dataset.
            self.n, self.dim = data.feat_full.shape
            edge_index = csr2ei(data.adj_full)
            self.Adj = torch.sparse_coo_tensor(
                edge_index, torch.ones(edge_index.shape[1]), (self.n, self.n)
            ).coalesce()
            identity = torch.sparse_coo_tensor(
                torch.arange(self.n).repeat(2, 1), torch.ones(self.n), (self.n, self.n)
            )
            self.Adj = self.Adj + identity
            features = self.normalize_data(data.feat_full.cpu())
            if name == "ogbn-arxiv":
                features = self.GCF(self.Adj, features, k=1)
            self.split_idx = torch.as_tensor(getattr(data, f"idx_{split}"), dtype=torch.long)
            self.n_split = len(self.split_idx)
            self.k = torch.tensor(max(1, round(self.n_split / batch_size)))
            self.split_feat = features[self.split_idx]
            self.split_label = torch.as_tensor(data.labels_full)[self.split_idx]
            self.split_method = split_method
            self.n_classes = data.nclass
            return
        path = osp.join("./data")
        if name in ["ogbn-arxiv"]:
            dataset = DataGraphSAINT(root=path, dataset=name)
            dataset.num_classes = 40
            data = dataset[0]
            self.n, self.dim = data.feat_full.shape
            labels = data.labels_full
            features = to_tensor(data.feat_full)
            edge_index = csr2ei(data.adj_full)
            values = torch.ones(edge_index.shape[1])
            Adj = torch.sparse_coo_tensor(edge_index, values, torch.Size([self.n, self.n]))
            sparse_eye = torch.sparse_coo_tensor(
                torch.arange(self.n).repeat(2, 1), torch.ones(self.n), (self.n, self.n)
            )
            self.Adj = Adj + sparse_eye

            features = self.normalize_data(features)
            features = self.GCF(self.Adj, features, k=1)

            self.split_idx = torch.tensor(data.idx_train)
            self.n_split = len(self.split_idx)
            self.k = torch.round(torch.tensor(self.n_split / batch_size)).to(torch.int).clamp(min=1)
            self.split_feat = features[self.split_idx]
            self.split_label = labels[self.split_idx]

            self.split_method = split_method
            self.n_classes = dataset.num_classes
        else:
            if name == "flickr":
                from torch_geometric.datasets import Flickr as DataSet
            elif name == "reddit":
                from torch_geometric.datasets import Reddit2 as DataSet

            Dataset = DataSet(root=path + f"/{name}")
            self.n, self.dim = Dataset[0].x.shape
            mask = split + "_mask"
            features = Dataset[0].x
            labels = Dataset[0].y
            edge_index = Dataset[0].edge_index

            values = torch.ones(edge_index.shape[1])
            Adj = torch.sparse_coo_tensor(edge_index, values, torch.Size([self.n, self.n]))
            sparse_eye = torch.sparse_coo_tensor(
                torch.arange(self.n).repeat(2, 1), torch.ones(self.n), (self.n, self.n)
            )
            self.Adj = Adj + sparse_eye
            features = self.normalize_data(features)
            # features      = self.GCF(self.Adj, features, k=2)
            self.split_idx = torch.where(Dataset[0][mask])[0]
            self.n_split = len(self.split_idx)
            self.k = torch.round(torch.tensor(self.n_split / batch_size)).to(torch.int).clamp(min=1)

            # Masked Adjacency Matrix
            optor_index = torch.cat(
                (
                    self.split_idx.reshape(1, self.n_split),
                    torch.tensor(range(self.n_split)).reshape(1, self.n_split),
                ),
                dim=0,
            )
            optor_value = torch.ones(self.n_split)
            optor_shape = torch.Size([self.n, self.n_split])
            optor = torch.sparse_coo_tensor(optor_index, optor_value, optor_shape)
            self.Adj_mask = torch.sparse.mm(torch.sparse.mm(optor.t(), self.Adj), optor)
            self.split_feat = features[self.split_idx]
            # self.split_feat   = self.GCF(self.Adj_mask, self.split_feat, k = 2)

            self.split_label = labels[self.split_idx]
            self.split_method = split_method
            self.n_classes = Dataset.num_classes

    def normalize_data(self, data):
        """Standardize feature columns, treating constant columns as unit variance.

        :param data: Feature tensor whose columns will be standardized.
        :returns: Column-standardized feature tensor.
        """
        mean = data.mean(dim=0)
        std = data.std(dim=0)
        std[std == 0] = 1
        normalized_data = (data - mean) / std
        return normalized_data

    def GCF(self, adj, x, k=2):
        """
        Graph convolution filter
        parameters:
            adj: torch.Tensor, adjacency matrix, must be self-looped
            x: torch.Tensor, features
            k: int, number of hops
        return:
            torch.Tensor, filtered features
        """
        n = adj.shape[0]
        ind = torch.tensor(range(n)).repeat(2, 1)
        adj = adj + torch.sparse_coo_tensor(ind, torch.ones(n), (n, n))

        D = torch.pow(torch.sparse.sum(adj, 1).to_dense(), -0.5)
        D = torch.sparse_coo_tensor(ind, D, (n, n))

        filter = torch.sparse.mm(torch.sparse.mm(D, adj), D)
        for i in range(k):
            x = torch.sparse.mm(filter, x)
        return x

    def properties(self):
        """Report partition count and graph dimensions for batched kernel training.

        :returns: Tuple ``(num_batches, num_split_nodes, num_classes, feature_dim, num_all_nodes)``.
        """
        return self.k, self.n_split, self.n_classes, self.dim, self.n

    def split_batch(self):
        """Assign split nodes to k-means partitions using the configured partition count.
        """
        if self.split_method == "kmeans":
            kmeans = KMeans(n_clusters=self.k.item(), n_init=10)
            from graphslim.reduction.cluster_ops import fitted_labels

            self.batch_labels = fitted_labels(kmeans, self.split_feat.numpy())

    def getitem(self, idx):
        """Extract node features, labels, and a locally indexed adjacency submatrix.

        :param idx: Index or indices to access.
        :returns: Tuple ``(features, labels, sparse_adjacency)``.
        """
        # idx   = [idx]
        n_idx = len(idx)
        idx_raw = self.split_idx[idx]
        feat = self.split_feat[idx]
        label = self.split_label[idx]
        # idx   = idx.tolist()

        optor_index = torch.cat(
            (idx_raw.reshape(1, n_idx), torch.tensor(range(n_idx)).reshape(1, n_idx)), dim=0
        )
        optor_value = torch.ones(n_idx)
        optor_shape = torch.Size([self.n, n_idx])
        optor = torch.sparse_coo_tensor(optor_index, optor_value, optor_shape)
        sub_A = torch.sparse.mm(torch.sparse.mm(optor.t(), self.Adj), optor)

        return (feat, label, sub_A)

    def get_batch(self, i):
        """Extract one graph partition with locally indexed adjacency and features.

        :param i: Zero-based partition index.
        :returns: Return value of ``getitem`` for the selected partition.
        """
        idx = torch.where(torch.tensor(self.batch_labels) == i)[0]
        batch_i = self.getitem(idx)
        return batch_i


class OgbDataLoader(nn.Module):
    """OGB-backed specialization of the large-graph partition loader.
    """
    def __init__(
        self, dataset_name="ogbn-arxiv", split="train", batch_size=5000, split_method="kmeans"
    ):
        """Initialize OgbDataLoader and its configuration.

        :param dataset_name: Dataset name or dataset collection, as required by this operation. Defaults to ``'ogbn-arxiv'``.
        :param split: Dataset split to load, such as ``train``, ``val``, or ``test``. Defaults to ``'train'``.
        :param batch_size: Approximate target number of nodes per partition; k-means partition sizes may differ. Defaults to ``5000``.
        :param split_method: Partitioning method used to assign nodes to batches. Defaults to ``'kmeans'``.
        """
        super(OgbDataLoader, self).__init__()


class DataGraphSAINT:
    """datasets used in GraphSAINT paper"""

    def __init__(self, root, dataset, **kwargs):
        """Initialize DataGraphSAINT and its configuration.

        :param root: Filesystem location used by this operation.
        :param dataset: Dataset name or dataset collection, as required by this operation.
        :param kwargs: Additional keyword options passed to the underlying implementation.
        """
        import gdown

        dataset = dataset.replace("-", "_")
        dataset_str = root + "/" + dataset + "/raw/"
        if not osp.exists(dataset_str):
            os.makedirs(dataset_str)
        required_files = ["adj_full.npz", "role.json", "feats.npy", "class_map.json"]
        missing_files = [
            fname for fname in required_files if not osp.exists(osp.join(dataset_str, fname))
        ]
        if missing_files:
            print("Downloading dataset")
            url = "https://drive.google.com/drive/folders/1VDobXR5KqKoov6WhYXFMwH4rN0FMnVOa"  # Change this to your actual file ID
            try:
                downloaded_items = gdown.download_folder(url=url, output=dataset_str, quiet=False)
            except Exception as exc:
                print(f"gdown download failed: {exc}")
                downloaded_items = None
            if downloaded_items:
                if isinstance(downloaded_items, str):
                    downloaded_items = [downloaded_items]
                for item_path in downloaded_items:
                    if not isinstance(item_path, str):
                        continue
                    if osp.isdir(item_path):
                        for filename in os.listdir(item_path):
                            src = osp.join(item_path, filename)
                            dst = osp.join(dataset_str, filename)
                            if osp.abspath(src) == osp.abspath(dst):
                                continue
                            shutil.move(src, dst)
                        if osp.abspath(item_path) != osp.abspath(dataset_str):
                            shutil.rmtree(item_path)
                    elif osp.isfile(item_path):
                        dst = osp.join(dataset_str, osp.basename(item_path))
                        if osp.abspath(item_path) != osp.abspath(dst):
                            shutil.move(item_path, dst)
            missing_files = [
                fname for fname in required_files if not osp.exists(osp.join(dataset_str, fname))
            ]
            if missing_files and dataset == "ogbn_arxiv":
                print("Falling back to OGB loader for ogbn-arxiv.")
                self._prepare_ogbn_arxiv_from_ogb(dataset_str, root)
                missing_files = [
                    fname
                    for fname in required_files
                    if not osp.exists(osp.join(dataset_str, fname))
                ]
            if missing_files:
                raise RuntimeError(f"Unable to prepare dataset files: {missing_files}")

        if dataset == "ogbn_arxiv":
            self.adj_full = sp.load_npz(dataset_str + "adj_full.npz")
            self.adj_full = self.adj_full + self.adj_full.T
            self.adj_full[self.adj_full > 1] = 1

        self.num_nodes = self.adj_full.shape[0]

        role = json.load(open(dataset_str + "role.json", "r"))
        self.idx_train = role["tr"]
        self.idx_test = role["te"]
        self.idx_val = role["va"]
        self.train_mask = index_to_mask(self.idx_train, self.num_nodes)
        self.test_mask = index_to_mask(self.idx_test, self.num_nodes)
        self.val_mask = index_to_mask(self.idx_val, self.num_nodes)

        self.feat_full = np.load(dataset_str + "feats.npy")
        # ---- normalize feat ----

        class_map = json.load(open(dataset_str + "class_map.json", "r"))
        self.labels_full = to_tensor(label=self.process_labels(class_map))

    def _prepare_ogbn_arxiv_from_ogb(self, dataset_str, root):
        """Download ogbn-arxiv and write GraphSAINT adjacency, feature, role, and label files.

        :param dataset_str: Directory in which to write the GraphSAINT-compatible dataset files.
        :param root: Filesystem location used by this operation.
        """
        from ogb.nodeproppred import PygNodePropPredDataset

        if torch_serialization is not None:
            add_safe_globals = getattr(torch_serialization, "add_safe_globals", None)
            if callable(add_safe_globals):
                safe_classes = []
                if DataEdgeAttr is not None:
                    safe_classes.append(DataEdgeAttr)
                if DataTensorAttr is not None:
                    safe_classes.append(DataTensorAttr)
                if GlobalStorage is not None:
                    safe_classes.append(GlobalStorage)
                if safe_classes:
                    add_safe_globals(safe_classes)
        ogb_root = osp.join(root, "ogb_cache")
        dataset = PygNodePropPredDataset(name="ogbn-arxiv", root=ogb_root)
        data = dataset[0]
        split_idx = dataset.get_idx_split()

        features = data.x.cpu().numpy().astype(np.float32)
        labels = data.y.view(-1).cpu().numpy().astype(np.int64)
        edge_index = data.edge_index.cpu().numpy()
        num_nodes = features.shape[0]

        values = np.ones(edge_index.shape[1], dtype=np.float32)
        adj = sp.coo_matrix((values, (edge_index[0], edge_index[1])), shape=(num_nodes, num_nodes))
        adj = adj.tocsr()
        adj = adj + adj.T
        adj[adj > 1] = 1

        sp.save_npz(osp.join(dataset_str, "adj_full.npz"), adj)
        np.save(osp.join(dataset_str, "feats.npy"), features)

        role = {
            "tr": split_idx["train"].cpu().tolist(),
            "va": split_idx["valid"].cpu().tolist(),
            "te": split_idx["test"].cpu().tolist(),
        }
        with open(osp.join(dataset_str, "role.json"), "w") as f:
            json.dump(role, f)

        class_map = {str(idx): int(label) for idx, label in enumerate(labels)}
        with open(osp.join(dataset_str, "class_map.json"), "w") as f:
            json.dump(class_map, f)

    def process_labels(self, class_map):
        """Convert GraphSAINT class maps to single-label or multilabel arrays.

        :param class_map: GraphSAINT mapping from node ID strings to class IDs or class indicator lists.
        :returns: NumPy class label array aligned to graph node IDs.
        """
        num_vertices = self.num_nodes
        if isinstance(list(class_map.values())[0], list):
            num_classes = len(list(class_map.values())[0])
            self.nclass = num_classes
            class_arr = np.zeros((num_vertices, num_classes))
            for k, v in class_map.items():
                class_arr[int(k)] = v
        else:
            class_arr = np.zeros(num_vertices, dtype=np.int64)
            for k, v in class_map.items():
                class_arr[int(k)] = v
            class_arr = class_arr - class_arr.min()
            self.nclass = max(class_arr) + 1
        return class_arr

    def get(self, idx):
        """Return the single graph represented by this dataset wrapper.

        :param idx: Index or indices to access.
        :returns: This ``DataGraphSAINT`` instance; the index is unused.
        """
        return self

    def __getitem__(self, idx):
        """Access the dataset single-graph view through ``get``.

        :param idx: Index or indices to access.
        :returns: This ``DataGraphSAINT`` instance.
        """
        return self.get(idx)
