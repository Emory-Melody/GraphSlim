import torch
import torch.nn as nn


class KernelRidgeRegression(nn.Module):
    """Differentiable kernel ridge predictor with a trace-scaled regularizer.
    """
    def __init__(self, kernel, ridge):
        """Initialize KernelRidgeRegression and its configuration.

        :param kernel: Callable graph kernel used to build support and cross-kernel matrices.
        :param ridge: Trace-scaled ridge coefficient for the support Gram matrix.
        """
        super(KernelRidgeRegression, self).__init__()
        self.kernel = kernel
        self.ridge = ridge

    def forward(self, G_t, G_s, y_t, y_s, E_t, E_s):
        """Fit kernel ridge coefficients on the synthetic support graph and predict target probabilities.

        The trace-scaled Gram solve uses float64 and retries with small diagonal
        jitter if necessary. Non-finite kernels raise ``FloatingPointError``.

        :param G_t: Target or synthetic support node features, respectively.
        :param G_s: Target or synthetic support node features, respectively.
        :param y_t: Target or synthetic support class targets, respectively, with one row per node.
        :param y_s: Target or synthetic support class targets, respectively, with one row per node.
        :param E_t: Target or synthetic support sparse adjacency, respectively.
        :param E_s: Target or synthetic support sparse adjacency, respectively.
        :returns: Tuple ``(target_class_probabilities, accuracy_fraction)``.
        """
        K_ss = self.kernel(G_s, G_s, E_s, E_s)
        K_ts = self.kernel(G_t, G_s, E_t, E_s)
        if not torch.isfinite(K_ss).all() or not torch.isfinite(K_ts).all():
            raise FloatingPointError("GCSNTK kernel contains non-finite values")
        n = len(G_s)
        # Small synthetic Gram systems need more precision than feature storage.
        # Keep the method's trace-scaled ridge and gradients through the solve.
        gram = K_ss.to(torch.float64)
        identity = torch.eye(n, device=gram.device, dtype=gram.dtype)
        ridge = self.ridge * torch.trace(gram) / n
        system = gram + ridge * identity
        targets = y_s.to(gram.dtype)
        coefficients, info = torch.linalg.solve_ex(system, targets)
        self.last_solve_jitter = 0.0
        if info.item() or not torch.isfinite(coefficients).all():
            scale = gram.detach().abs().max()
            scale = torch.where(scale > 0, scale, torch.ones_like(scale))
            for relative in (1e-12, 1e-10, 1e-8, 1e-6):
                jitter = scale * relative
                coefficients, info = torch.linalg.solve_ex(system + jitter * identity, targets)
                if not info.item() and torch.isfinite(coefficients).all():
                    self.last_solve_jitter = float(jitter)
                    break
            else:
                raise torch.linalg.LinAlgError("GCSNTK Gram solve failed after diagonal retries")
        pred = (K_ts.to(gram.dtype) @ coefficients).to(y_s.dtype)
        pred = nn.functional.softmax(pred, dim=1)
        correct = (
            torch.eq(pred.argmax(1).to(torch.float32), y_t.argmax(1).to(torch.float32)).sum().item()
        )
        acc = correct / len(y_t)
        return pred, acc
