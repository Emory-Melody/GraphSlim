from itertools import product

import numpy as np
import scipy
import torch
import torch.nn.functional as F
import torch_sparse
from torch import nn


class _SymmetricInverse(torch.autograd.Function):
    """Spectral inverse maps with a finite derivative at repeated eigenvalues.

    SGDD's SVD expression is f(A)=sign(A)|A|**-p for symmetric adjacency,
    with p=1 or 1/2. Differentiating singular vectors separately produces 0/0
    for repeated singular values. The divided-difference derivative of f(A)
    depends only on the matrix function and has a well-defined repeated-root
    limit. Modes below the existing 0.009 cutoff are consistently truncated.
    """

    @staticmethod
    def forward(ctx, matrix):
        """Evaluate signed thresholded spectral inverses and save eigenpairs for differentiation.

        :param ctx: Active Click context, or autograd context for a custom tensor operation.
        :param matrix: Input matrix to transform.
        :returns: Tuple of inverse square-root and inverse tensors in the input dtype.
        """
        if matrix.ndim != 2 or matrix.shape[0] != matrix.shape[1]:
            raise ValueError("SGDD spectral inverse requires a square matrix")
        if not torch.isfinite(matrix).all():
            raise FloatingPointError("SGDD spectral inverse received non-finite values")
        work = matrix.to(torch.float64)
        work = (work + work.T) * 0.5
        try:
            values, vectors = torch.linalg.eigh(work)
        except torch.linalg.LinAlgError:
            if work.device.type == "cpu":
                raise
            # Same symmetric problem/precision; only the decomposition backend
            # changes if the CUDA eigensolver cannot converge.
            values, vectors = torch.linalg.eigh(work.cpu())
            values, vectors = values.to(work.device), vectors.to(work.device)
        ctx.save_for_backward(values, vectors)
        ctx.dtype = matrix.dtype
        magnitude = values.abs().clamp_min(0.009)
        active = (values.abs() > 0.009).to(values.dtype)
        inverse = active * values.sign() / magnitude
        root = active * values.sign() / magnitude.sqrt()
        return (
            ((vectors * root) @ vectors.T).to(matrix.dtype),
            ((vectors * inverse) @ vectors.T).to(matrix.dtype),
        )

    @staticmethod
    def backward(ctx, root_gradient, inverse_gradient):
        """Differentiate spectral inverses with stable divided differences for repeated eigenvalues.

        :param ctx: Active Click context, or autograd context for a custom tensor operation.
        :param root_gradient: Upstream gradients for the inverse square-root and inverse outputs.
        :param inverse_gradient: Upstream gradients for the inverse square-root and inverse outputs.
        :returns: Symmetric gradient with respect to the input matrix.
        """
        values, vectors = ctx.saved_tensors
        magnitude = values.abs().clamp_min(0.009)
        active = (values.abs() > 0.009).to(values.dtype)
        difference = values[:, None] - values[None, :]
        scale = torch.maximum(values.abs()[:, None], values.abs()[None, :]).clamp_min(1)
        repeated = difference.abs() <= 16 * torch.finfo(values.dtype).eps * scale
        denominator = torch.where(repeated, torch.ones_like(difference), difference)
        result = torch.zeros_like(vectors)
        for gradient, power in [(root_gradient, 0.5), (inverse_gradient, 1.0)]:
            if gradient is None:
                continue
            function = active * values.sign() / magnitude.pow(power)
            derivative = -power * active / magnitude.pow(power + 1)
            divided = (function[:, None] - function[None, :]) / denominator
            divided = torch.where(
                repeated, (derivative[:, None] + derivative[None, :]) * 0.5, divided
            )
            symmetric = (gradient.to(values.dtype) + gradient.T.to(values.dtype)) * 0.5
            result = result + vectors @ (divided * (vectors.T @ symmetric @ vectors)) @ vectors.T
        return result.to(ctx.dtype)


def mx_inv(mx, device):
    """Compute the thresholded symmetric inverse of a dense or supported sparse matrix.

    :param mx: Input matrix to transform.
    :param device: Target PyTorch device, such as ``cpu`` or ``cuda:0``.
    :returns: Dense inverse tensor; eigenvalues with absolute value at most 0.009 are suppressed.
    """
    if isinstance(mx, torch_sparse.tensor.SparseTensor):
        mx = mx.to_dense()
    elif scipy.sparse.issparse(mx):
        mx = torch.FloatTensor(mx.toarray()).to(device)
    return _SymmetricInverse.apply(mx)[1]


def mx_inv_sqrt(mx):
    """Compute thresholded symmetric inverse square-root and inverse operators.

    :param mx: Input matrix to transform.
    :returns: Tuple ``(signed_inverse_square_root, signed_inverse)``.
    """
    return _SymmetricInverse.apply(mx)


def mx_tr(mx):
    """Sum the diagonal entries of a matrix.

    :param mx: Input matrix to transform.
    :returns: Scalar matrix trace.
    """
    return mx.diag().sum()


def get_mgrid(sidelen, dim=2):
    """Create flattened two- or three-dimensional coordinates normalized to the interval [-1, 1].

    :param sidelen: Grid side length, or a tuple with one length per coordinate dimension.
    :param dim: Coordinate dimensionality: two or three. Defaults to ``2``.
    :returns: Float32 coordinate tensor of shape ``(product(sidelen), dim)``.
    """
    if isinstance(sidelen, int):
        sidelen = dim * (sidelen,)

    if dim == 2:
        pixel_coords = np.stack(np.mgrid[: sidelen[0], : sidelen[1]], axis=-1)[None, ...].astype(
            np.float32
        )
        pixel_coords[0, :, :, 0] = pixel_coords[0, :, :, 0] / (sidelen[0] - 1)
        pixel_coords[0, :, :, 1] = pixel_coords[0, :, :, 1] / (sidelen[1] - 1)
    elif dim == 3:
        pixel_coords = np.stack(np.mgrid[: sidelen[0], : sidelen[1], : sidelen[2]], axis=-1)[
            None, ...
        ].astype(np.float32)
        pixel_coords[..., 0] = pixel_coords[..., 0] / max(sidelen[0] - 1, 1)
        pixel_coords[..., 1] = pixel_coords[..., 1] / (sidelen[1] - 1)
        pixel_coords[..., 2] = pixel_coords[..., 2] / (sidelen[2] - 1)
    else:
        raise NotImplementedError("Not implemented for dim=%d" % dim)

    pixel_coords -= 0.5
    pixel_coords *= 2.0
    pixel_coords = torch.Tensor(pixel_coords).view(-1, dim)
    return pixel_coords.to(torch.float32)


class Sine(nn.Module):
    """Elementwise high-frequency sine activation for graphon generation.
    """
    def __init__(self):
        """Initialize Sine and its configuration.
        """
        super().__init__()

    def forward(self, input):
        """Apply the sinusoidal activation ``sin(30 * input)``.

        :param input: Input feature tensor.
        :returns: Elementwise activated tensor.
        """
        return torch.sin(30 * input)


class EdgeBlock(nn.Module):
    """Linear, batch normalization, and ReLU block for edge features.
    """
    def __init__(self, in_, out_, dtype=torch.float32) -> None:
        """Initialize EdgeBlock and its configuration.

        :param in_: Input or output width of the edge block, respectively.
        :param out_: Input or output width of the edge block, respectively.
        :param dtype: Desired numeric dtype. Defaults to ``torch.float32``.
        """
        super(EdgeBlock, self).__init__()
        self.net = nn.Sequential(
            nn.Linear(in_, out_, dtype=dtype),
            nn.BatchNorm1d(out_, dtype=dtype),
            nn.ReLU(),
        )

    def forward(self, x):
        """Transform concatenated endpoint features through the edge block network.

        :param x: Node feature matrix with one row per node.
        :returns: Edge representation tensor.
        """
        return self.net(x)


class GraphonLearner(nn.Module):
    """Feature-conditioned implicit graphon generator with spectral transport guidance.
    """
    def __init__(
        self,
        node_feature,
        nfeat=256,
        nnodes=50,
        device="cuda",
        args={},
        num_hidden_layers=3,
        **kwargs,
    ):
        """Initialize GraphonLearner and its configuration.

        :param node_feature: Input feature width used to condition the graphon generator.
        :param nfeat: Number of input features per node. Defaults to ``256``.
        :param nnodes: Number of nodes used to construct candidate edge pairs. Defaults to ``50``.
        :param device: Target PyTorch device, such as ``cpu`` or ``cuda:0``. Defaults to ``'cuda'``.
        :param args: Configuration namespace containing the options used by this operation. Defaults to ``{}``.
        :param num_hidden_layers: Requested hidden layer count retained in the graphon configuration. Defaults to ``3``.
        :param kwargs: Additional keyword options passed to the underlying implementation.
        """
        super().__init__()
        self.num_hidden_layers = num_hidden_layers
        self.step_size = nnodes
        self.ep_ratio = args.ep_ratio
        self.sinkhorn_iter = args.sinkhorn_iter
        self.mx_size = args.mx_size

        self.edge_index = np.array(list(product(range(self.step_size), range(self.step_size)))).T

        self.net0 = nn.ModuleList(
            [
                EdgeBlock(node_feature * 2, nfeat),
                EdgeBlock(nfeat, nfeat),
                nn.Linear(nfeat, 1, dtype=torch.float32),
            ]
        )

        self.net1 = nn.ModuleList(
            [
                EdgeBlock(2, nfeat),
                EdgeBlock(nfeat, nfeat),
                nn.Linear(nfeat, 1, dtype=torch.float32),
            ]
        )

        self.P = nn.Parameter(
            torch.Tensor(self.mx_size, self.step_size).to(torch.float32).uniform_(0, 1)
        )  # transport plan
        self.Lx_inv = None

        self.output = nn.Linear(nfeat, 1)
        self.act = F.relu
        self.device = device
        self.reset_parameters()

    def reset_parameters(self):
        """Reset trainable layers and normalization state using their initialization rules.
        """
        def weight_reset(m):
            """Reset linear and batch normalization submodule parameters.

            :param m: PyTorch submodule to reset.
            """
            if isinstance(m, nn.Linear):
                m.reset_parameters()
            if isinstance(m, nn.BatchNorm1d):
                m.reset_parameters()

        self.apply(weight_reset)

    def forward(self, c, inference=False, Lx=None, compute_opt_loss=True):
        """Generate dense graphon adjacency and optionally compute its spectral transport loss.

        :param c: Synthetic node features used to form endpoint pairs.
        :param inference: Whether to switch the graph generator to evaluation mode. Defaults to ``False``.
        :param Lx: Optional real-graph operator whose inverse is cached for spectral guidance. Defaults to ``None``.
        :param compute_opt_loss: Whether to evaluate spectral guidance in addition to generating adjacency. Defaults to ``True``.
        :returns: Adjacency alone in inference mode, otherwise ``(adjacency, spectral_loss)``.
        """
        if inference == True:
            self.eval()
        else:
            self.train()
        x0 = get_mgrid(c.shape[0]).to(self.device)
        c = torch.cat([c[self.edge_index[0]], c[self.edge_index[1]]], axis=1)
        for layer in range(len(self.net0)):
            c = self.net0[layer](c)
            if layer == 0:
                x = self.net1[layer](x0)
            else:
                x = self.net1[layer](x)

            if layer != (len(self.net0) - 1):
                # use node feature to guide the graphon generating process
                x = x * c
            else:
                x = (1 - self.ep_ratio) * x + self.ep_ratio * c

        # x = self.output(x)
        # adj = self.output(x).reshape(self.step_size, self.step_size)
        adj = x.reshape(self.step_size, self.step_size)

        adj = (adj + adj.T) / 2
        adj = torch.sigmoid(adj)
        adj = adj - torch.diag(torch.diag(adj, 0))

        if inference == True:
            return adj
        if not compute_opt_loss:
            return adj, adj.new_zeros(())
        if Lx is not None and self.Lx_inv is None:
            self.Lx_inv = mx_inv(Lx, c.device)
        # try:
        #     opt_loss = self.opt_loss(adj)
        # except Exception as e:
        #     print(e)
        #     opt_loss = torch.tensor(0).to(self.device)
        opt_loss = self.opt_loss(adj)
        return adj, opt_loss

    def opt_loss(self, adj):
        """Compute spectral transport guidance using learned coupling and cached real-graph inverse.

        :param adj: Graph adjacency; rows and columns refer to the same node ordering as the features.
        :returns: Scalar spectral guidance loss.
        """
        Ly_inv_rt, Ly_inv = mx_inv_sqrt(adj)
        m = self.step_size
        P = self.P.abs()

        for _ in range(self.sinkhorn_iter):
            P = P / P.sum(dim=1, keepdim=True)
            P = P / P.sum(dim=0, keepdim=True)

        # if self.args.use_symeig:
        # sqrt = torch.symeig(
        root, plan, original = Ly_inv_rt.double(), self.P.double(), self.Lx_inv.double()
        covariance = root @ plan.T @ original @ plan @ root
        eigenvalues = torch.linalg.eigvalsh((covariance + covariance.T) * 0.5)
        loss = torch.abs(mx_tr(Ly_inv) * m - 2 * torch.sqrt(eigenvalues.clamp(min=2e-20)).sum())
        return loss

    @torch.no_grad()
    def inference(self, c):
        """Generate graphon adjacency in inference mode.

        :param c: Synthetic node feature matrix.
        :returns: Dense synthetic adjacency.
        """
        return self.forward(c, inference=True)
