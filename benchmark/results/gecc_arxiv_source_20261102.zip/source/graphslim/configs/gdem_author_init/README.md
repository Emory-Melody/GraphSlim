# GDEM author-initializer profiles

Replay overrides for `benchmark/reproduce_table9.py` (`manifest.replay.gdem = {"config": "gdem_author_init"}`),
passed through `--config`. `gdem_normalized_operator` trains the downstream GCN on the synthetic
`I - L` operator directly, as the GDEM authors do; `gdem_init_profile` holds the released
`config_init.json` entry (epochs, learning rates, weight decay, dropout, MLP epochs) for the
feature initializer. Yelp has no released entry, so only the operator alignment applies.
