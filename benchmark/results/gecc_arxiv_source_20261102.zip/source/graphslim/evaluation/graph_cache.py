"""Process-local GPU graph reuse and shared CPU sparse normalization cache.

Only static evaluation inputs are cached. NumPy/SciPy contents are hashed;
Torch storage/version keys invalidate mutated tensors. Cache construction keeps
the legacy float32 input -> SciPy normalization -> float32 transposed operator.
"""

from collections import OrderedDict
from contextlib import contextmanager
import fcntl
import hashlib
import inspect
import json
from pathlib import Path
import tempfile
import time

import numpy as np
import scipy
import scipy.sparse as sp
import torch
from torch_sparse import SparseTensor

from graphslim.utils import (
    gcn_normalize_adj,
    is_sparse_tensor,
    normalize_adj_tensor,
    sparse_gcn_norm,
    to_tensor,
)


def array_digest(array):
    """Hash an array shape, dtype, and contiguous byte content with SHA-256.

    :param array: NumPy-compatible array whose shape, dtype, and values define the digest.
    :returns: Hexadecimal digest string.
    """
    array = np.asarray(array)
    digest = hashlib.sha256()
    digest.update(str((array.shape, array.dtype.str)).encode())
    if array.flags.c_contiguous:
        digest.update(memoryview(array).cast("B"))
    else:
        digest.update(array.tobytes(order="C"))
    return digest.hexdigest()


def input_key(value):
    """Identify cache inputs by tensor identity and version or by array content.

    :param value: Value to convert or identify.
    :returns: Hashable tuple; unsupported input types raise ``TypeError``.
    """
    if isinstance(value, torch.Tensor):
        return (
            "torch",
            id(value),
            value.data_ptr() if value.layout == torch.strided else 0,
            value._version,
            str(value.device),
            str(value.dtype),
            tuple(value.shape),
            str(value.layout),
        )
    if sp.issparse(value):
        if sp.isspmatrix_csr(value) or sp.isspmatrix_csc(value):
            arrays = (value.data, value.indices, value.indptr)
        else:
            coo = value.tocoo()
            arrays = (coo.data, coo.row, coo.col)
        return ("scipy", value.format, value.shape, *(array_digest(a) for a in arrays))
    if isinstance(value, np.ndarray):
        return ("numpy", array_digest(value))
    raise TypeError(f"Unsupported evaluation cache input: {type(value).__name__}")


def normalization_key(adjacency):
    """Hash adjacency identity together with normalization source and dependency versions.

    :param adjacency: Graph adjacency; rows and columns refer to the same node ordering as the features.
    :returns: SHA-256 key used for normalized graph files.
    """
    contract = (
        "float32-scipy-gcn-float32-transposed-csr-v1",
        inspect.getsource(gcn_normalize_adj),
        inspect.getsource(sparse_gcn_norm),
        np.__version__,
        scipy.__version__,
        torch.__version__,
        input_key(adjacency),
    )
    return hashlib.sha256(repr(contract).encode()).hexdigest()


@contextmanager
def entry_lock(path):
    """Hold an exclusive file lock while reading or writing one cache entry.

    :param path: Filesystem location used by this operation.
    :returns: Context manager that releases the lock on exit.
    """
    with path.open("a+") as handle:
        fcntl.flock(handle, fcntl.LOCK_EX)
        try:
            yield
        finally:
            fcntl.flock(handle, fcntl.LOCK_UN)


def normalized_csr(adjacency):
    """Build the legacy float32 GCN operator on the CPU before device transfer.

    :param adjacency: Graph adjacency; rows and columns refer to the same node ordering as the features.
    :returns: Transposed, normalized float32 SciPy CSR matrix.
    """
    matrix = adjacency.astype(np.float32).tocsr()
    if not matrix.has_canonical_format:
        # Preserve the legacy coalescing order for duplicated sparse entries.
        from graphslim.utils import to_scipy

        matrix = to_scipy(to_tensor(adjacency, device="cpu").coalesce())
    normalized = gcn_normalize_adj(matrix)
    return normalized.astype(np.float32).transpose().tocsr()


class EvaluationGraphCache:
    """Bounded graph preparation cache with optional checksummed CPU normalization files.
    """
    def __init__(self, device, directory=None, max_entries=3):
        """Initialize EvaluationGraphCache and its configuration.

        :param device: Target PyTorch device, such as ``cpu`` or ``cuda:0``.
        :param directory: Filesystem location used by this operation. Defaults to ``None``.
        :param max_entries: Maximum number of prepared graphs retained in memory. Defaults to ``3``.
        """
        if max_entries < 1:
            raise ValueError("max_entries must be positive")
        self.device = str(torch.device(device))
        self.directory = Path(directory) if directory else None
        if self.directory:
            self.directory.mkdir(parents=True, exist_ok=True)
        self.max_entries = max_entries
        self.entries = OrderedDict()
        # Keep source references alive so a recycled Python id cannot hit stale tensors.
        self.sources = OrderedDict()
        self.stats = dict(
            hits=0,
            misses=0,
            cpu_builds=0,
            disk_hits=0,
            hashing_seconds=0.0,
            preparation_seconds=0.0,
        )

    def clear(self):
        """Release all in-memory prepared graph entries and their source references.
        """
        self.entries.clear()
        self.sources.clear()

    def _cpu_graph(self, adjacency):
        """Load or build a normalized CPU CSR adjacency with disk integrity checks.

        :param adjacency: Graph adjacency; rows and columns refer to the same node ordering as the features.
        :returns: Normalized SciPy CSR matrix.
        """
        if self.directory is None:
            self.stats["cpu_builds"] += 1
            return normalized_csr(adjacency)
        key = normalization_key(adjacency)
        matrix_path = self.directory / f"{key}.npz"
        metadata_path = self.directory / f"{key}.json"
        with entry_lock(self.directory / f"{key}.lock"):
            if matrix_path.exists() and metadata_path.exists():
                metadata = json.loads(metadata_path.read_text())
                with matrix_path.open("rb") as file:
                    actual = hashlib.file_digest(file, "sha256").hexdigest()
                if metadata.get("normalization_key") != key or metadata.get("sha256") != actual:
                    raise RuntimeError("Evaluation normalization cache checksum mismatch")
                self.stats["disk_hits"] += 1
                return sp.load_npz(matrix_path)
            matrix = normalized_csr(adjacency)
            with tempfile.NamedTemporaryFile(
                dir=self.directory, suffix=".npz", delete=False
            ) as file:
                temporary = Path(file.name)
            try:
                sp.save_npz(temporary, matrix, compressed=False)
                with temporary.open("rb") as file:
                    sha256 = hashlib.file_digest(file, "sha256").hexdigest()
                temporary.replace(matrix_path)
                metadata = dict(
                    normalization_key=key,
                    sha256=sha256,
                    shape=matrix.shape,
                    nnz=matrix.nnz,
                    dtype=str(matrix.dtype),
                )
                with tempfile.NamedTemporaryFile(
                    mode="w", dir=self.directory, suffix=".json", delete=False
                ) as file:
                    json.dump(metadata, file)
                    temporary_metadata = Path(file.name)
                temporary_metadata.replace(metadata_path)
            finally:
                temporary.unlink(missing_ok=True)
            self.stats["cpu_builds"] += 1
            return matrix

    def get(self, features, adjacency, normalize=True):
        """Prepare graph tensors and reuse cached results for unchanged, non-gradient inputs.

        Inputs requiring gradients and unsupported mutable representations use
        the uncached conversion path. Least-recently-used entries are evicted
        when the in-memory capacity is exceeded.

        :param features: Node feature matrix with one row per node.
        :param adjacency: Graph adjacency; rows and columns refer to the same node ordering as the features.
        :param normalize: Whether to normalize the adjacency before use. Defaults to ``True``.
        :returns: Tuple ``(device_features, device_adjacency)`` with optional adjacency normalization.
        """
        if any(
            isinstance(value, torch.Tensor) and value.requires_grad
            for value in (features, adjacency)
        ):
            features, adjacency = to_tensor(features, adjacency, device=self.device)
            return features, normalize_adj_tensor(
                adjacency, sparse=is_sparse_tensor(adjacency)
            ) if normalize else adjacency
        start = time.perf_counter()
        try:
            key = (input_key(features), input_key(adjacency), normalize)
        except TypeError:
            # Unknown mutable representations retain the uncached legacy path.
            features, adjacency = to_tensor(features, adjacency, device=self.device)
            return features, normalize_adj_tensor(
                adjacency, sparse=is_sparse_tensor(adjacency)
            ) if normalize else adjacency
        self.stats["hashing_seconds"] += time.perf_counter() - start
        if key in self.entries:
            self.stats["hits"] += 1
            self.entries.move_to_end(key)
            self.sources.move_to_end(key)
            return self.entries[key]
        self.stats["misses"] += 1
        start = time.perf_counter()
        converted_features = to_tensor(features, device=self.device)
        if normalize and sp.issparse(adjacency):
            matrix = self._cpu_graph(adjacency)
            converted_adjacency = SparseTensor.from_scipy(matrix).to(self.device)
        else:
            converted_adjacency = to_tensor(adjacency, device=self.device)
            if normalize:
                converted_adjacency = normalize_adj_tensor(
                    converted_adjacency, sparse=is_sparse_tensor(converted_adjacency)
                )
        output = converted_features, converted_adjacency
        self.entries[key] = output
        self.sources[key] = (features, adjacency)
        while len(self.entries) > self.max_entries:
            oldest, _ = self.entries.popitem(last=False)
            self.sources.pop(oldest)
        self.stats["preparation_seconds"] += time.perf_counter() - start
        return output


def attach_evaluation_cache(model, data, args):
    """Attach a shared graph cache to supported GCN or SGC models when enabled.

    :param model: Model instance used for training, prediction, or cache attachment.
    :param data: Graph data containing features, adjacency, labels, and split indices.
    :param args: Configuration namespace containing the options used by this operation.
    """
    if not getattr(args, "eval_cache", False):
        return
    # Enable the automatic path only for models with exact CUDA training parity.
    # Attention and architectures with their own preprocessing keep their path.
    if model.__class__.__name__ not in ("GCN", "SGC"):
        return
    device = str(torch.device(args.device))
    directory = getattr(args, "eval_cache_dir", None)
    cache = getattr(data, "_evaluation_graph_cache", None)
    if (
        cache is None
        or cache.device != device
        or cache.directory != (Path(directory) if directory else None)
    ):
        cache = EvaluationGraphCache(device, directory)
        data._evaluation_graph_cache = cache
    model._evaluation_graph_cache = cache
