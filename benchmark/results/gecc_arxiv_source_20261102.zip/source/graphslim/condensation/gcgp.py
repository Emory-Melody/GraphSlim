"""GCGP: Gaussian-process prediction matching with learned synthetic targets.

Wang et al., arXiv:2501.02565. Kernel formulas follow the MIT-licensed
author release (https://github.com/WANGLin0126/GCGP); see THIRD_PARTY_NOTICES.
No GNN is trained inside condensation. Synthetic features/targets ARE optimized.
"""

import math

import torch
import torch.nn.functional as F

from graphslim.reduction.lightweight import (
    LightweightReducer,
    normalized_adjacency,
    propagate,
    sparse_tensor,
)


def neural_kernel(x, y, layers=2):
    """Sum input and successive erf activation covariance kernels using the released SGNK recurrence.

    :param x: Left node feature matrix.
    :param y: Right node feature matrix.
    :param layers: Number of layers. Defaults to ``2``.
    :returns: Dense cross-kernel matrix between the input feature rows.
    """
    cross = x @ y.T
    xx, yy = x.square().sum(1)[:, None], y.square().sum(1)[None, :]
    result = cross
    for _ in range(layers):
        denominator = torch.sqrt(1 + 2 * xx) * torch.sqrt(1 + 2 * yy)
        cross = (2 / math.pi) * torch.asin((2 * cross / denominator).clamp(-1 + 1e-7, 1 - 1e-7))
        xx = (2 / math.pi) * torch.asin(2 * xx / (1 + 2 * xx))
        yy = (2 / math.pi) * torch.asin(2 * yy / (1 + 2 * yy))
        result = result + cross
    return result


def released_neural_kernel(x, y, layers=2, diagonal_x=None):
    """Author SGNK arithmetic, including GEMM diagonals and sqrt-product order.

    MIT-licensed GCGP release; see THIRD_PARTY_NOTICES. Only a detached fixed
    query diagonal may be cached. The historical row-norm implementation remains
    the default; select ``gcgp_arithmetic='released'`` explicitly for this path.

    :param x: Left feature matrix with shape ``(num_left, feature_dim)``.
    :param y: Right feature matrix with shape ``(num_right, feature_dim)``.
    :param layers: Number of erf covariance updates; the input linear kernel is
        also included in the sum. Defaults to ``2``.
    :param diagonal_x: Optional cached ``diag(x @ x.T)`` with shape
        ``(num_left, 1)``. Use only for fixed, detached query features.
        ``None`` computes the diagonal from ``x``.
    :returns: Cross-kernel matrix with shape ``(num_left, num_right)``.
    """
    xx = torch.diag(x @ x.t()).reshape(-1, 1) if diagonal_x is None else diagonal_x
    yy = torch.diag(y @ y.t()).reshape(1, -1)
    cross = x @ y.t()
    kernels = [cross]
    for _ in range(layers):
        a_xy = (2 * cross / (torch.sqrt(1 + 2 * xx) * torch.sqrt(1 + 2 * yy))).clamp(-1, 1)
        a_xx = (2 * xx / (torch.sqrt(1 + 2 * xx) * torch.sqrt(1 + 2 * xx))).clamp(-1, 1)
        a_yy = (2 * yy / (torch.sqrt(1 + 2 * yy) * torch.sqrt(1 + 2 * yy))).clamp(-1, 1)
        cross, xx, yy = (2 / math.pi * torch.asin(t) for t in (a_xy, a_xx, a_yy))
        kernels.append(cross)
    return sum(kernels)


def _relu_update(covariance, diagonal_x, diagonal_y):
    """Update covariance and derivative factors using the released ReLU kernel recurrence.

    :param covariance: Cross-covariance matrix between the two node sets.
    :param diagonal_x: Per-node standard deviations for the left or right covariance matrix.
    :param diagonal_y: Per-node standard deviations for the left or right covariance matrix.
    :returns: Tuple ``(updated_covariance, derivative_factor)``.
    """
    scale = diagonal_x[:, None] * diagonal_y[None, :]
    correlation = (covariance / scale.clamp_min(1e-12)).clamp(-0.9999, 0.9999)
    activated = (
        correlation * (math.pi - torch.acos(correlation)) + torch.sqrt(1 - correlation.square())
    ) / math.pi
    # The released NTK/SNTK recurrence evaluates this factor AFTER the covariance
    # update. Preserve that author convention rather than silently substituting
    # a different kernel's derivative factor.
    derivative = (math.pi - torch.acos(activated.clamp(-1, 1))) / math.pi
    covariance = activated * scale
    return covariance, derivative


def tangent_kernel(x, y, adjacency_x=None, adjacency_y=None, layers=2, hops=0):
    """Compute a ReLU NTK, optionally including structure-based adjacency aggregation.

    :param x: Left node feature matrix.
    :param y: Right node feature matrix.
    :param adjacency_x: Adjacency operator for the left or right feature set, respectively. Defaults to ``None``.
    :param adjacency_y: Adjacency operator for the left or right feature set, respectively. Defaults to ``None``.
    :param layers: Number of layers. Defaults to ``2``.
    :param hops: Number of graph aggregation stages; zero evaluates the feature-only NTK. Defaults to ``0``.
    :returns: Dense tangent kernel matrix; both adjacencies are required when hops is positive.
    """
    cross, self_x, self_y = x @ y.T, x @ x.T, y @ y.T
    tangent = cross
    for _ in range(max(hops, 1)):
        if hops:
            cross = adjacency_x @ cross @ adjacency_y.T
            tangent = adjacency_x @ tangent @ adjacency_y.T
            self_x = adjacency_x @ self_x @ adjacency_x.T
            self_y = adjacency_y @ self_y @ adjacency_y.T
        for _ in range(layers):
            diag_x = self_x.diagonal().clamp_min(1e-12).sqrt()
            diag_y = self_y.diagonal().clamp_min(1e-12).sqrt()
            cross, derivative = _relu_update(cross, diag_x, diag_y)
            tangent = tangent * derivative + cross
            self_x, _ = _relu_update(self_x, diag_x, diag_x)
            self_y, _ = _relu_update(self_y, diag_y, diag_y)
    return tangent


def concrete_adjacency(alpha, epoch=0, training=True, uniform=None):
    """Sample symmetric BinConcrete connectivity with annealed temperature and identity diagonal.

    :param alpha: Trainable nonnegative connectivity parameters before symmetrization.
    :param epoch: Current zero-based optimization epoch. Defaults to ``0``.
    :param training: Whether to apply dropout rather than return the input unchanged. Defaults to ``True``.
    :param uniform: Optional pre-drawn symmetric uniform noise for reproducible BinConcrete sampling. Defaults to ``None``.
    :returns: Dense adjacency sample during training or thresholded adjacency during evaluation.
    """
    alpha = (alpha + alpha.T) / 2
    if training:
        if uniform is None:
            uniform = torch.rand_like(alpha)
            uniform = torch.triu(uniform) + torch.triu(uniform, diagonal=1).T
        uniform = uniform.clamp(1e-7, 1 - 1e-7)
        temperature = max(0.3 * (0.01 / 0.3) ** (epoch / 100), 0.01)
        adjacency = torch.sigmoid(
            (uniform.log() - torch.log1p(-uniform) + (alpha.clamp_min(0) + 1e-8).log())
            / temperature
        )
    else:
        adjacency = (alpha > 1).to(alpha.dtype)
    identity = torch.eye(len(alpha), device=alpha.device, dtype=alpha.dtype)
    return adjacency * (1 - identity) + identity


def gp_predict(cross_kernel, synthetic_kernel, targets, ridge, released_arithmetic=False):
    """Solve a trace-regularized support kernel system and apply the released output softmax.

    :param cross_kernel: Target-to-support kernel matrix.
    :param synthetic_kernel: Support-to-support kernel matrix.
    :param targets: Synthetic support class targets.
    :param ridge: Trace-scaled ridge coefficient for the support Gram matrix.
    :param released_arithmetic: Whether to preserve the released solve expression instead of flooring its ridge term. Defaults to ``False``.
    :returns: Target class probability matrix.
    """
    if ridge <= 0:
        raise ValueError("gcgp_ridge must be positive")
    n = len(synthetic_kernel)
    regularizer = ridge * synthetic_kernel.trace() / n
    identity = torch.eye(n, device=synthetic_kernel.device, dtype=synthetic_kernel.dtype)
    if released_arithmetic:
        # Tensor division matters for Float32 CUDA's gradient rounding.
        count = torch.tensor(n, device=synthetic_kernel.device)
        matrix = synthetic_kernel + ridge * synthetic_kernel.trace() * identity / count
        return (cross_kernel @ torch.linalg.solve(matrix, targets)).softmax(1)
    coefficients = torch.linalg.solve(
        synthetic_kernel + regularizer.clamp_min(1e-8) * identity, targets
    )
    return (cross_kernel @ coefficients).softmax(1)


class GCGP(LightweightReducer):
    """Optimize synthetic features and soft targets through graph Gaussian-process kernel prediction.
    """
    def reduce(self, data, verbose=True, save=True):
        """Optimize synthetic features and soft targets through graph Gaussian-process kernel prediction.

        :param data: Graph data containing features, adjacency, labels, and split indices.
        :param verbose: Whether to print progress and diagnostic information. Defaults to ``True``.
        :param save: Whether to write the reduced graph checkpoint to ``args.save_path``. Defaults to ``True``.
        :returns: The input data with synthetic graph attributes populated at evaluation checkpoints.
        """
        args = self.args
        features, adjacency, train, labels = self.inputs(data)
        steps = getattr(args, "gcgp_k", 4)
        filtered_all = propagate(normalized_adjacency(adjacency, self.device), features, steps)
        filtered = filtered_all[train].detach()
        target = F.one_hot(labels, data.nclass).float()
        size = max(1, round(len(train) * args.reduction_rate))
        self.check_budget(size)
        # The release initializes features and continuous synthetic targets uniformly.
        synthetic = torch.nn.Parameter(torch.rand(size, features.shape[1], device=self.device))
        synthetic_targets = torch.nn.Parameter(torch.rand(size, data.nclass, device=self.device))
        alpha = torch.nn.Parameter(2 * torch.rand(size, size, device=self.device))
        parameters = [synthetic, synthetic_targets]
        learn_adjacency = getattr(args, "gcgp_learn_adj", False)
        kernel = getattr(args, "gcgp_kernel", "SGNK").upper()
        if kernel not in ("SGNK", "NTK", "SNTK"):
            raise ValueError("gcgp_kernel must be SGNK, NTK or SNTK")
        if learn_adjacency and kernel != "SNTK":
            raise ValueError("SGNK/NTK ignore adjacency; gcgp_learn_adj requires SNTK")
        if learn_adjacency:
            parameters.append(alpha)
        optimizer = torch.optim.Adam(parameters, lr=getattr(args, "gcgp_lr", 0.01))
        original_training_adjacency = adjacency[train.cpu().numpy()][:, train.cpu().numpy()]
        original_training_adjacency.setdiag(1)
        batch_size = getattr(args, "gcgp_batch_size", 1024)
        if batch_size < 1:
            raise ValueError("gcgp_batch_size must be positive")
        # Released large-graph scripts sum the gradients of several training
        # batches before each optimizer step (ogbn-arxiv: 10, Reddit: 8).
        accumulate = int(getattr(args, "gcgp_accumulate_steps", 1))
        if accumulate < 1:
            raise ValueError("gcgp_accumulate_steps must be positive")
        ridge = getattr(args, "gcgp_ridge", 0.5)
        loss_history = []
        layers = getattr(args, "gcgp_layers", 2)
        arithmetic = getattr(args, "gcgp_arithmetic", "package")
        if arithmetic not in ("package", "released"):
            raise ValueError("gcgp_arithmetic must be package or released")
        released = arithmetic == "released"
        original_diagonal = (
            torch.diag(filtered @ filtered.t()).reshape(-1, 1)
            if released and kernel == "SGNK" and len(train) <= batch_size
            else None
        )

        def kernel_pair(original, synthetic):
            """Evaluate support and target kernel matrices under the selected kernel arithmetic.

            :param original: Original training or synthetic support feature matrix, respectively.
            :param synthetic: Original training or synthetic support feature matrix, respectively.
            :returns: Tuple of support and target-to-support Gram matrices.
            """
            if kernel == "NTK":
                return (
                    tangent_kernel(synthetic, synthetic, layers=layers),
                    tangent_kernel(original, synthetic, layers=layers),
                )
            function = released_neural_kernel if released else neural_kernel
            ss = function(synthetic, synthetic, layers)
            ts = (
                function(original, synthetic, layers, diagonal_x=original_diagonal)
                if released and original_diagonal is not None and len(original) == len(filtered)
                else function(original, synthetic, layers)
            )
            return ss, ts

        n_train = len(train)
        batches_per_epoch = math.ceil(n_train / batch_size) if n_train > batch_size else 1
        optimizer_steps = 0
        for epoch in range(args.epochs):
            # Every epoch is one pass over the shuffled training nodes, as released.
            if batches_per_epoch > 1:
                permutation = torch.randperm(n_train, device=self.device)
                batches = torch.chunk(permutation, batches_per_epoch)
            else:
                batches = [torch.arange(n_train, device=self.device)]
            epoch_loss = 0.0
            optimizer.zero_grad()
            for index, chosen in enumerate(batches):
                original = filtered[chosen]
                reduced_adjacency = (
                    concrete_adjacency(alpha, epoch)
                    if learn_adjacency
                    else torch.eye(size, device=self.device)
                )
                if kernel in ("SGNK", "NTK"):
                    ss, ts = kernel_pair(original, synthetic)
                else:
                    chosen_cpu = chosen.cpu().numpy()
                    aa = sparse_tensor(
                        original_training_adjacency[chosen_cpu][:, chosen_cpu], self.device
                    )
                    hops = getattr(args, "gcgp_hops", 2)
                    ss = tangent_kernel(
                        synthetic, synthetic, reduced_adjacency, reduced_adjacency, layers, hops
                    )
                    ts = tangent_kernel(original, synthetic, aa, reduced_adjacency, layers, hops)
                prediction = gp_predict(ts, ss, synthetic_targets, ridge, released)
                loss = F.mse_loss(prediction, target[chosen])
                if not torch.isfinite(loss):
                    raise FloatingPointError("Non-finite GCGP loss")
                (loss / accumulate).backward()
                epoch_loss += float(loss.detach())
                if (index + 1) % accumulate == 0 or index == len(batches) - 1:
                    optimizer.step()
                    optimizer.zero_grad()
                    optimizer_steps += 1
            loss_history.append(epoch_loss / len(batches))
        reduced_adjacency = (
            concrete_adjacency(alpha, training=False)
            if learn_adjacency
            else torch.eye(size, device=self.device)
        )
        gp_test_accuracy = self.gp_test_accuracy(
            data, filtered_all, steps, kernel, layers, released, synthetic, synthetic_targets, ridge
        )
        # The GP predicts softmax(K b) with b solved from the optimized targets, so
        # the targets live in logit space. Downstream GNNs regress class
        # probabilities, so the saved labels are softmax(targets) unless the raw
        # released tensors are requested explicitly.
        save_logits = bool(getattr(args, "gcgp_save_logits", False))
        labels_syn = synthetic_targets.detach()
        if not save_logits:
            labels_syn = labels_syn.softmax(1)
        return self.finish(
            data,
            synthetic,
            reduced_adjacency,
            labels_syn,
            save=save,
            verbose=verbose,
            gnn_training_steps=0,
            optimization_steps=args.epochs,
            optimizer_steps=optimizer_steps,
            batches_per_epoch=batches_per_epoch,
            accumulate_steps=accumulate,
            kernel=kernel,
            arithmetic=arithmetic,
            training_batch_size=min(batch_size, n_train),
            final_train_loss=loss_history[-1],
            gp_test_accuracy=gp_test_accuracy,
            label_type="optimized logits" if save_logits else "softmax of optimized targets",
        )

    def gp_test_accuracy(
        self, data, filtered_all, steps, kernel, layers, released, synthetic, targets, ridge
    ):
        """Test accuracy of the GP predictor itself, the metric the GCGP paper reports.

        Only kernels without adjacency terms are evaluated. The value is a
        diagnostic recorded in the reduction metadata; it never selects anything.

        :param data: Graph data containing test features, labels and split indices.
        :param filtered_all: Propagated full-graph features used to select test
            rows in the transductive setting; unused in the inductive setting.
        :param steps: Number of test-graph propagation steps in the inductive setting.
        :param kernel: Feature kernel, ``'SGNK'`` or ``'NTK'``; other values
            return ``None`` without evaluating test nodes.
        :param layers: Number of nonlinear updates in the selected kernel.
        :param released: Whether to use the released SGNK arithmetic and the
            released ridge convention in GP prediction.
        :param synthetic: Synthetic feature matrix used as GP support points.
        :param targets: Synthetic target matrix, with one row per support point.
        :param ridge: Ridge coefficient passed to ``gp_predict``.
        :returns: Test classification accuracy in ``[0, 1]``, or ``None`` for
            kernels that require adjacency terms.
        """
        if kernel not in ("SGNK", "NTK"):
            return None
        with torch.no_grad():
            if self.setting == "trans":
                test_index = torch.as_tensor(data.idx_test, dtype=torch.long, device=self.device)
                test_features = filtered_all[test_index]
            else:
                test_features = propagate(
                    normalized_adjacency(data.adj_test, self.device),
                    torch.as_tensor(data.feat_test, dtype=torch.float32, device=self.device),
                    steps,
                )
            test_labels = torch.as_tensor(data.labels_test, dtype=torch.long, device=self.device)
            synthetic = synthetic.detach()
            if kernel == "NTK":
                ss = tangent_kernel(synthetic, synthetic, layers=layers)
            else:
                function = released_neural_kernel if released else neural_kernel
                ss = function(synthetic, synthetic, layers)
            correct = 0
            for chunk in torch.split(test_features, 10000):
                if kernel == "NTK":
                    ts = tangent_kernel(chunk, synthetic, layers=layers)
                else:
                    ts = function(chunk, synthetic, layers)
                prediction = gp_predict(ts, ss, targets.detach(), ridge, released)
                correct += int((prediction.argmax(1) == test_labels[: len(chunk)]).sum())
                test_labels = test_labels[len(chunk) :]
            return correct / len(test_features)
