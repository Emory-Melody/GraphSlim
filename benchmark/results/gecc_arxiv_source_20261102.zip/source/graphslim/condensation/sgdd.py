from graphslim.models import get_model_class
from collections import Counter

import torch.nn as nn

from graphslim.condensation.gcond_base import GCondBase
from graphslim.condensation.utils import match_loss
from graphslim.dataset.utils import save_reduced
from graphslim.evaluation import *
from graphslim.models import *
from graphslim.utils import *
from tqdm import trange


def full_class_linear_gradients(features, labels, weight, bias, classes):
    """Compute exact mean cross-entropy linear-weight gradients for each training class.

    :param features: Node feature matrix with one row per node.
    :param labels: Node labels in the same node ordering as the corresponding features.
    :param weight: Linear classifier weight matrix.
    :param bias: Linear classifier bias vector.
    :param classes: Number of output classes.
    :returns: Class-by-input-feature-by-output-class gradient tensor; missing training classes raise ValueError.
    """
    residual = (features @ weight + bias).softmax(1) - F.one_hot(labels, classes)
    counts = torch.bincount(labels, minlength=classes)
    if (counts == 0).any():
        raise ValueError("Full-class SGDD requires training examples for every class")
    if len(features) <= 4096:
        membership = F.one_hot(labels, classes).T.to(features.dtype)
        return torch.einsum("kn,nf,nc->kfc", membership, features, residual) / counts[:, None, None]
    return torch.stack([
        features[labels == c].T @ residual[labels == c] / counts[c]
        for c in range(classes)
    ])


def full_class_gradient_distance(real, synthetic, weights):
    """Compute class-weighted cosine gradient discrepancy for the released SGDD objective.

    :param real: Real-graph reference gradient tensor.
    :param synthetic: Synthetic class gradient tensor.
    :param weights: Per-class weights applied to the gradient distance.
    :returns: Scalar sum of weighted class gradient distances.
    """
    real, synthetic = real.transpose(1, 2), synthetic.transpose(1, 2)
    cosine = (real * synthetic).sum(-1) / (real.norm(dim=-1) * synthetic.norm(dim=-1) + 1e-6)
    return ((1 - cosine).sum(-1) * weights).sum()


class SGDD(GCondBase):
    """
    "Does Graph Distillation See Like Vision Dataset Counterpart?" https://openreview.net/pdf?id=VqIWgUVsXc
    """

    def __init__(self, setting, data, args, **kwargs):
        """Initialize SGDD and its configuration.

        :param setting: Graph learning setting: ``trans`` for the full graph or ``ind`` for split subgraphs.
        :param data: Graph data containing features, adjacency, labels, and split indices.
        :param args: Configuration namespace containing the options used by this operation.
        :param kwargs: Additional keyword options passed to the underlying implementation.
        """
        super(SGDD, self).__init__(setting, data, args, **kwargs)

        self.pge = IGNR(
            node_feature=self.d, nfeat=128, nnodes=self.nnodes_syn, device=self.device, args=args
        ).to(self.device)
        # self.reset_parameters()
        self.optimizer_feat = torch.optim.Adam([self.feat_syn], lr=args.lr_feat)
        self.optimizer_pge = torch.optim.Adam(self.pge.parameters(), lr=args.lr_adj)
        print("adj_syn:", (self.nnodes_syn, self.nnodes_syn), "feat_syn:", self.feat_syn.shape)

    def label_regularization(self, adjacency, labels):
        """Penalize cross-label adjacency through one-hot feature smoothing when enabled.

        :param adjacency: Graph adjacency; rows and columns refer to the same node ordering as the features.
        :param labels: Node labels in the same node ordering as the corresponding features.
        :returns: Scalar label-smoothing loss or zero when the objective is disabled.
        """
        if getattr(self.args, "sgdd_author_objective", False) and self.args.beta > 0:
            one_hot_labels = F.one_hot(labels.long(), num_classes=self.data.nclass).float()
            return self.args.beta * regularization(adjacency, one_hot_labels)
        return adjacency.new_zeros(())

    @verbose_time_memory
    def reduce(self, data, verbose=True):
        """Learn synthetic features and adjacency with gradient matching and graphon-based structural guidance.

        :param data: Graph data containing features, adjacency, labels, and split indices.
        :param verbose: Whether to print progress and diagnostic information. Defaults to ``True``.
        :returns: The input data with synthetic graph attributes populated at evaluation checkpoints.
        """
        args = self.args
        if getattr(args, "sgdd_full_class_gradients", False):
            return self._reduce_full_class(data, verbose)

        if data.adj_full.shape[0] < args.mx_size:
            args.mx_size = data.adj_full.shape[0]
        else:
            data.adj_mx = data.adj_full[: args.mx_size, : args.mx_size]

        feat_syn, labels_syn = to_tensor(self.feat_syn, label=data.labels_syn, device=self.device)
        if args.setting == "trans":
            features, adj, labels = to_tensor(
                data.feat_full, data.adj_full, label=data.labels_full, device=self.device
            )
        else:
            features, adj, labels = to_tensor(
                data.feat_train, data.adj_train, label=data.labels_train, device=self.device
            )

        # initialization the features
        feat_init = self.init()
        self.feat_syn.data.copy_(feat_init)

        adj = normalize_adj_tensor(adj, sparse=True)

        outer_loop, inner_loop = self.get_loops(args)
        loss_avg = 0
        best_val = 0

        model = get_model_class(args.condense_model)(
            feat_syn.shape[1], args.hidden, data.nclass, args
        ).to(self.device)
        for it in trange(args.epochs):
            model.initialize()
            model_parameters = list(model.parameters())
            optimizer_model = torch.optim.Adam(model_parameters, lr=args.lr)
            model.train()

            for ol in range(outer_loop):
                adj_syn, opt_loss = self.pge(self.feat_syn, Lx=data.adj_mx)
                self.adj_syn = normalize_adj_tensor(adj_syn, sparse=False)

                model = self.check_bn(model)
                loss = self.train_class(model, adj, features, labels, labels_syn, args)
                loss = loss + self.label_regularization(adj_syn, labels_syn)
                if args.opt_scale > 0:
                    loss_opt = args.opt_scale * opt_loss
                else:
                    loss_opt = torch.tensor(0)

                loss = loss + loss_opt
                loss_avg += loss.item()

                # update sythetic graph
                self.optimizer_feat.zero_grad()
                self.optimizer_pge.zero_grad()
                loss.backward()

                if it % 50 < 10:
                    self.optimizer_pge.step()
                else:
                    self.optimizer_feat.step()
                feat_syn_inner = self.feat_syn.detach()
                adj_syn_inner = self.pge.inference(feat_syn_inner)
                adj_syn_inner_norm = normalize_adj_tensor(adj_syn_inner, sparse=False)
                feat_syn_inner_norm = feat_syn_inner
                for j in range(inner_loop):
                    optimizer_model.zero_grad()
                    output_syn_inner = model.forward(feat_syn_inner_norm, adj_syn_inner_norm)
                    loss_syn_inner = F.nll_loss(output_syn_inner, labels_syn)
                    loss_syn_inner.backward()
                    optimizer_model.step()

            loss_avg /= data.nclass * outer_loop

            if it in args.checkpoints:
                self.adj_syn = adj_syn_inner
                data.adj_syn, data.feat_syn, data.labels_syn = (
                    self.adj_syn.detach(),
                    self.feat_syn.detach(),
                    labels_syn.detach(),
                )
                best_val = self.intermediate_evaluation(best_val, loss_avg)

        return data

    def _reduce_full_class(self, data, verbose=False):
        """Full training-class objective, with bias after SGC propagation.

        This explicit profile replaces sampled-neighborhood gradients with
        exact class gradients. The linear teacher stays fixed within an epoch
        when inner_loop=0, so its real gradients can be reused exactly.

        :param data: Graph data used for the full-class objective; synthetic
            graph attributes are populated at configured checkpoints.
        :param verbose: Compatibility argument; currently unused by this
            profile. Defaults to ``False``.
        :returns: The input data with synthetic graph attributes populated at
            configured evaluation checkpoints.
        :raises ValueError: If the teacher, gradient-matching configuration or
            graph-generator size is incompatible with this profile.
        :raises FloatingPointError: If the optimization loss is non-finite.
        """
        args = self.args
        if args.ntrans != 1 or args.inner_loop != 0 or args.dis_metric != "ours":
            raise ValueError("Full-class SGDD requires ntrans=1, inner_loop=0, dis_metric=ours")
        if args.condense_model != "SGC" or args.with_bn or args.dropout != 0:
            raise ValueError("Full-class SGDD requires the one-transform SGC without BN/dropout")
        if self.pge.P.shape[0] > data.adj_full.shape[0]:
            raise ValueError("Full-class SGDD mx_size exceeds the original graph")
        data.adj_mx = data.adj_full[:self.pge.P.shape[0], :self.pge.P.shape[0]]
        self.feat_syn.data.copy_(self.init())
        source_features = data.feat_full if args.setting == "trans" else data.feat_train
        source_adjacency = data.adj_full if args.setting == "trans" else data.adj_train
        features, adjacency = to_tensor(source_features, source_adjacency, device=self.device)
        propagation = normalize_adj_tensor(adjacency, sparse=True)
        real_features = features
        with torch.no_grad():
            for _ in range(args.nlayers):
                real_features = propagation @ real_features
            if args.setting == "trans":
                real_features = real_features[data.idx_train]
            real_features = real_features.detach()
        real_labels = torch.as_tensor(data.labels_train, device=self.device).long()
        labels_syn = torch.as_tensor(self.labels_syn, device=self.device).long()
        weights = torch.tensor([self.num_class_dict[c] for c in range(data.nclass)], device=self.device).float()
        weights = weights / weights.max()
        teacher = SGC(self.d, args.hidden, data.nclass, args).to(self.device)
        best_val = 0
        for epoch in trange(args.epochs):
            teacher.initialize()
            weight, bias = teacher.layers[0].weight.detach(), teacher.layers[0].bias.detach()
            with torch.no_grad():
                real_gradients = full_class_linear_gradients(real_features, real_labels, weight, bias, data.nclass)
            update_graph = epoch % 50 < 10
            for _ in range(args.outer_loop):
                adjacency_syn, structure_loss = self.pge(self.feat_syn, Lx=data.adj_mx,
                    compute_opt_loss=update_graph and args.opt_scale > 0)
                normalized = normalize_adj_tensor(adjacency_syn, sparse=False)
                filtered = self.feat_syn
                for _ in range(args.nlayers):
                    filtered = normalized @ filtered
                synthetic_gradients = full_class_linear_gradients(filtered, labels_syn, weight, bias, data.nclass)
                loss = full_class_gradient_distance(real_gradients, synthetic_gradients, weights)
                loss = loss + self.label_regularization(adjacency_syn, labels_syn)
                if update_graph and args.opt_scale > 0:
                    loss = loss + args.opt_scale * structure_loss
                if not torch.isfinite(loss):
                    raise FloatingPointError("Full-class SGDD loss is not finite")
                self.optimizer_feat.zero_grad(); self.optimizer_pge.zero_grad()
                loss.backward()
                if update_graph:
                    self.optimizer_pge.step()
                else:
                    self.optimizer_feat.step()
            if epoch in args.checkpoints:
                data.adj_syn = self.pge.inference(self.feat_syn.detach())
                data.feat_syn, data.labels_syn = self.feat_syn.detach(), labels_syn
                best_val = self.intermediate_evaluation(best_val, float(loss.detach()))
        return data
