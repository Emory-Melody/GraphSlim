from tqdm import trange
import copy
import os
import os.path as osp

import networkx as nx
from graphslim.condensation.gcond_base import GCondBase
from graphslim.condensation.utils import *
from graphslim.dataset.utils import save_reduced
from graphslim.evaluation.utils import verbose_time_memory
from graphslim.utils import *
from graphslim.models import *
from torch.nn import Parameter
from torch import nn


class GDEM(GCondBase):
    """
    "Graph Condensation for Graph Neural Networks" https://cse.msu.edu/~jinwei2/files/GCond.pdf
    """

    def __init__(self, setting, data, args, **kwargs):
        """Initialize GDEM and its configuration.

        :param setting: Graph learning setting: ``trans`` for the full graph or ``ind`` for split subgraphs.
        :param data: Graph data containing features, adjacency, labels, and split indices.
        :param args: Configuration namespace containing the options used by this operation.
        :param kwargs: Additional keyword options passed to the underlying implementation.
        """
        super(GDEM, self).__init__(setting, data, args, **kwargs)
        args.eigen_k = min(args.eigen_k, self.nnodes_syn)
        self.eigenvecs_syn = Parameter(
            torch.FloatTensor(self.nnodes_syn, args.eigen_k).to(self.device)
        )

        self.y_syn = to_tensor(label=self.labels_syn, device=self.device)
        self.x_syn = self.feat_syn

        init_syn_feat = self.init_feat()
        init_syn_eigenvecs = self.get_init_syn_eigenvecs(self.nnodes_syn, data.nclass)
        init_syn_eigenvecs = init_syn_eigenvecs[:, : args.eigen_k]
        self.x_syn.data.copy_(init_syn_feat)
        self.eigenvecs_syn.data.copy_(init_syn_eigenvecs)

    @verbose_time_memory
    def reduce(self, data, verbose=True):
        """Match real and synthetic spectral feature statistics while learning eigenvectors and features.

        :param data: Graph data containing features, adjacency, labels, and split indices.
        :param verbose: Whether to print progress and diagnostic information. Defaults to ``True``.
        :returns: The input data with synthetic graph attributes populated at evaluation checkpoints.
        """
        args = self.args
        pge = self.pge
        # calculate eigenvalues and eigenvectors
        dataset_dir = osp.join(args.load_path, args.dataset)
        # OGB datasets live under their own folder name; the LCC/eigen cache uses the CLI name.
        os.makedirs(dataset_dir, exist_ok=True)
        if not osp.exists(f"{dataset_dir}/idx_map.npy"):
            idx_lcc, adj_norm_lcc, _ = get_largest_cc(data.adj_full, data.num_nodes, args.dataset)
            np.save(f"{dataset_dir}/idx_lcc.npy", idx_lcc)

            L_lcc = sp.eye(len(idx_lcc)) - adj_norm_lcc
            get_eigh(L_lcc, f"{args.dataset}", True, root=args.load_path)

            idx_train_lcc, idx_map = get_train_lcc(
                idx_lcc=idx_lcc,
                idx_train=data.idx_train,
                y_full=data.y,
                num_nodes=data.num_nodes,
                num_classes=data.nclass,
            )
            np.save(f"{dataset_dir}/idx_train_lcc.npy", idx_train_lcc)
            np.save(f"{dataset_dir}/idx_map.npy", idx_map)
            print("preprocess done")
        else:
            idx_lcc = np.load(f"{dataset_dir}/idx_lcc.npy")
            idx_train_lcc = np.load(f"{dataset_dir}/idx_train_lcc.npy")
            idx_map = np.load(f"{dataset_dir}/idx_map.npy")

        eigenvals_lcc, eigenvecs_lcc = load_eigen(args.dataset, args.load_path)
        eigenvals_lcc = torch.FloatTensor(eigenvals_lcc)
        eigenvecs_lcc = torch.FloatTensor(eigenvecs_lcc)

        n_syn = int(len(data.idx_train) * args.reduction_rate)
        eigenvals, eigenvecs = get_syn_eigen(
            real_eigenvals=eigenvals_lcc,
            real_eigenvecs=eigenvecs_lcc,
            eigen_k=args.eigen_k,
            ratio=args.ratio,
        )

        co_x_trans_real = get_subspace_covariance_matrix(eigenvecs, data.feat_full[idx_lcc]).to(
            self.device
        )
        embed_sum = get_embed_sum(
            eigenvals=eigenvals, eigenvecs=eigenvecs, x=data.feat_full[idx_lcc]
        )
        embed_sum = embed_sum[idx_map, :]
        real_classes = F.one_hot(data.y[idx_train_lcc], num_classes=data.nclass).float().T
        observed_classes = real_classes.sum(1).to(self.device) > 0
        if not observed_classes.any():
            raise ValueError("The largest connected component has no training nodes")
        observed_index = observed_classes.nonzero().flatten()
        embed_mean_real = (
            get_embed_mean(
                embed_sum=embed_sum, label=data.y[idx_train_lcc], class_matrix=real_classes
            )
            .to(self.device)
            .index_select(0, observed_index)
        )
        class_identity = torch.eye(len(observed_index), device=self.device)
        optimizer_feat = self.optimizer_feat
        optimizer_eigenvec = torch.optim.Adam([self.eigenvecs_syn], lr=args.lr_eigenvec)
        eigenvals_syn = eigenvals.to(self.device)
        best_val = 0
        bar = trange(args.epochs)
        class_matrix = F.one_hot(self.y_syn, num_classes=data.nclass).float().T

        def spectral_loss():
            """Combine spectral covariance, class embedding, and eigenvector orthogonality terms.

            :returns: Tuple ``(eigenbasis_loss, class_loss, orthogonality_loss, weighted_total_loss)``.
            """
            loss = 0.0
            x_syn = self.x_syn
            eigenvecs_syn = self.eigenvecs_syn

            # eigenbasis match
            co_x_trans_syn = get_subspace_covariance_matrix(eigenvecs=eigenvecs_syn, x=x_syn).to(
                self.device
            )  # kdd
            eigen_match_loss = F.mse_loss(co_x_trans_syn, co_x_trans_real)
            loss += args.alpha * eigen_match_loss

            # class loss
            embed_sum_syn = get_embed_sum(
                eigenvals=eigenvals_syn, eigenvecs=eigenvecs_syn, x=x_syn
            ).to(self.device)
            embed_mean_syn = get_embed_mean(
                embed_sum=embed_sum_syn, label=self.y_syn, class_matrix=class_matrix
            ).to(self.device)  # cd
            cov_embed = embed_mean_real @ embed_mean_syn.index_select(0, observed_index).T
            class_loss = F.mse_loss(cov_embed, class_identity)
            loss += args.beta * class_loss

            # orthog_norm
            orthog_syn = eigenvecs_syn.T @ eigenvecs_syn
            iden = torch.eye(args.eigen_k, device=self.device)
            orthog_norm = F.mse_loss(orthog_syn, iden)
            loss += args.gamma * orthog_norm
            return eigen_match_loss, class_loss, orthog_norm, loss

        for ep in bar:
            optimizer_eigenvec.zero_grad()
            optimizer_feat.zero_grad()
            eigen_match_loss, class_loss, orthog_norm, loss = spectral_loss()
            loss.backward()
            if verbose and ep in args.checkpoints:
                print(f"epoch: {ep}")
                print(f"eigen_match_loss: {eigen_match_loss}")
                print(f"args.alpha * eigen_match_loss: {args.alpha * eigen_match_loss}")

                print(f"class_loss: {class_loss}")
                print(f"args.beta * class_loss: {args.beta * class_loss}")

                print(f"orthog_norm: {orthog_norm}")
                print(f"args.gamma * orthog_norm: {args.gamma * orthog_norm}")

            # update U:
            if ep % (args.e1 + args.e2) < args.e1:
                optimizer_eigenvec.step()
            else:
                optimizer_feat.step()

            eigenvecs_syn = self.eigenvecs_syn.detach()
            eigenvals_syn = eigenvals_syn.detach()

            if ep in args.checkpoints:
                L_syn = eigenvecs_syn @ torch.diag(eigenvals_syn) @ eigenvecs_syn.T
                adj_syn = torch.eye(self.nnodes_syn, device=self.device) - L_syn
                x_syn, y_syn = self.x_syn.detach(), self.y_syn
                data.adj_syn, data.feat_syn, data.labels_syn = adj_syn, x_syn, y_syn
                best_val = self.intermediate_evaluation(best_val)

        return data

    def get_eigenspace_embed(self, eigen_vecs, x):
        """Project features onto individual rank-one eigenspaces.

        :param eigen_vecs: Eigenvectors stored as rows, with shape ``(num_components, num_nodes)``.
        :param x: Node feature matrix with one row per node.
        :returns: Tensor of shape ``(num_eigenvectors, num_nodes, feature_dim)``.
        """
        eigen_vecs = eigen_vecs.unsqueeze(2)  # k * n * 1
        eigen_vecs_t = eigen_vecs.permute(0, 2, 1)  # k * 1 * n
        eigenspace = torch.bmm(eigen_vecs, eigen_vecs_t)  # knn
        embed = torch.matmul(eigenspace, x)  # knn*nd=knd
        return embed

    def get_real_embed(self, k, L, x):
        """Stack successive real-graph Laplacian applications to features.

        :param k: Number of spectral components or propagation steps to use.
        :param L: Graph Laplacian or graph filtering operator.
        :param x: Node feature matrix with one row per node.
        :returns: Tensor containing ``L @ x`` through ``L**k @ x``.
        """
        filtered_x = x

        emb_list = []
        for i in range(k):
            filtered_x = L @ filtered_x
            emb_list.append(filtered_x)

        embed = torch.stack(emb_list, dim=0)
        return embed

    def get_syn_embed(self, k, eigenvals, eigen_vecs, x):
        """Filter synthetic features in spectral coordinates and reconstruct each propagation step.

        :param k: Number of spectral components or propagation steps to use.
        :param eigenvals: Eigenvalues ordered consistently with the eigenvector columns.
        :param eigen_vecs: Eigenvectors stored as rows, with shape ``(num_components, num_nodes)``.
        :param x: Node feature matrix with one row per node.
        :returns: Stacked node feature embeddings with shape ``(k, num_nodes, feature_dim)``.
        """
        trans_x = eigen_vecs @ x
        filtered_x = trans_x

        emb_list = []
        for i in range(k):
            filtered_x = torch.diag(eigenvals) @ filtered_x
            emb_list.append(eigen_vecs.T @ filtered_x)

        embed = torch.stack(emb_list, dim=0)
        return embed

    def get_init_syn_feat(self, dataset, reduction_rate):
        """Load a precomputed feature initialization for the configured dataset, rate, and seed.

        :param dataset: Dataset name or dataset collection, as required by this operation.
        :param reduction_rate: Fraction of labeled training nodes used to set the synthetic node budget.
        :returns: Saved feature tensor loaded on the CPU.
        """
        expID = self.args.seed
        init_syn_x = torch.load(
            f"./initial_feat/{dataset}/x_init_{reduction_rate}_{expID}.pt", map_location="cpu"
        )
        return init_syn_x

    def get_init_syn_eigenvecs(self, n_syn, num_classes):
        """Initialize eigenvectors from a class-sized stochastic block model graph.

        :param n_syn: Number of nodes in the graph.
        :param num_classes: Number of output classes.
        :returns: Float eigenvector tensor on the reducer device.
        """
        n_nodes_per_class = n_syn // num_classes
        n_nodes_last = n_syn % num_classes

        size = [n_nodes_per_class for i in range(num_classes - 1)] + (
            [n_syn - (num_classes - 1) * n_nodes_per_class]
            if n_nodes_last != 0
            else [n_nodes_per_class]
        )
        prob_same_community = 1 / num_classes
        prob_diff_community = prob_same_community / 3

        prob = [[prob_diff_community for i in range(num_classes)] for i in range(num_classes)]
        for idx in range(num_classes):
            prob[idx][idx] = prob_same_community

        syn_graph = nx.stochastic_block_model(size, prob)
        syn_graph_adj = nx.adjacency_matrix(syn_graph)
        syn_graph_L = gcn_normalize_adj(syn_graph_adj)
        syn_graph_L = np.eye(n_syn) - syn_graph_L
        _, eigen_vecs = get_eigh(syn_graph_L, "", False)

        return torch.FloatTensor(eigen_vecs).to(self.device)

    def mlp_trainer(self, args, data, verbose):
        """Train the feature initialization classifier and restore its best validation weights.

        :param args: Configuration namespace containing the options used by this operation.
        :param data: Graph data containing features, adjacency, labels, and split indices.
        :param verbose: Whether to print progress and diagnostic information.
        :returns: Trained MLP selected using validation accuracy.
        """
        x_full, y_full = to_tensor(data.feat_full, label=data.labels_full, device=self.device)

        model = MLP(
            num_features=x_full.shape[1],
            num_classes=data.nclass,
            hidden_dim=args.hidden,
            dropout=args.dropout,
        ).to(self.device)
        optimizer = torch.optim.Adam(model.parameters(), lr=args.lr, weight_decay=args.weight_decay)

        best_acc_val = 0
        y_train, y_val, y_test = to_tensor(
            label1=data.labels_train,
            label2=data.labels_val,
            label=data.labels_test,
            device=self.device,
        )
        feat_train, feat_val = to_tensor(data.feat_train, data.feat_val, device=self.device)

        lr = args.lr
        mlp_epochs = getattr(args, "gdem_mlp_epochs", 2000)
        restart_epoch = mlp_epochs // 2 if getattr(args, "gdem_init_profile", None) else 500
        for i in range(mlp_epochs):
            if i == restart_epoch and i > 0:
                lr = lr * 0.1
                optimizer = torch.optim.Adam(
                    model.parameters(), lr=args.lr, weight_decay=args.weight_decay
                )

            model.train()
            optimizer.zero_grad()

            loss_train = F.nll_loss(model.forward(feat_train), y_train)
            loss_train.backward()
            optimizer.step()

            with torch.no_grad():
                model.eval()
                output = model.forward(feat_val)
                # loss_val = F.nll_loss(output, y_val)

                acc_val = accuracy(output, y_val)

                if acc_val > best_acc_val:
                    best_acc_val = acc_val
                    weights = copy.deepcopy(model.state_dict())

        model.load_state_dict(weights)

        return model

    def init_feat(self):
        """Initialize synthetic features with Xavier values and optimize them against a trained MLP.

        :returns: Trainable synthetic feature tensor stored as ``self.x_syn``.
        """
        args = self.args
        data = self.data
        labels_syn = to_tensor(label=data.labels_syn, device=self.device)
        profile = getattr(args, "gdem_init_profile", {})
        mlp_args = copy.copy(args)
        for key in ("lr", "weight_decay", "dropout"):
            if key in profile:
                setattr(mlp_args, key, profile[key])
        mlp_args.gdem_mlp_epochs = profile.get("epoch_mlp", 2000)

        # feat_syn is allocated with torch.empty; start from the author's
        # Xavier initialization (GDEM feat_init.py) instead of arbitrary memory.
        nn.init.xavier_uniform_(self.x_syn.data)
        optimizer_feat = torch.optim.Adam(
            [self.x_syn], lr=profile.get("lr_feat", args.lr_feat),
            weight_decay=profile.get("wd_feat", 0),
        )

        model = self.mlp_trainer(mlp_args, data, verbose=False)
        model.train()

        for i in range(profile.get("epoch", 2000)):
            output = model(self.x_syn)
            loss = F.nll_loss(output, labels_syn)
            #
            optimizer_feat.zero_grad()
            loss.backward()
            optimizer_feat.step()
        return self.x_syn


class MLP(nn.Module):
    """Two-layer feature classifier used for GDEM feature initialization.
    """
    def __init__(self, num_features, num_classes, hidden_dim, dropout):

        """Initialize MLP and its configuration.

        :param num_features: Number of input features per node.
        :param num_classes: Number of output classes.
        :param hidden_dim: Hidden representation width.
        :param dropout: Dropout probability.
        """
        super(MLP, self).__init__()
        self.dropout = dropout
        self.layers = nn.ModuleList(
            [nn.Linear(num_features, hidden_dim), nn.Linear(hidden_dim, num_classes)]
        )
        self.reset_parameter()

    def reset_parameter(self):
        """Reset linear weights with Xavier initialization and zero biases.
        """
        for lin in self.layers:
            nn.init.xavier_uniform_(lin.weight.data)
            if lin.bias is not None:
                lin.bias.data.zero_()

    def forward(self, x):
        """Apply the feature initialization MLP with ReLU and dropout.

        :param x: Node feature matrix with one row per node.
        :returns: Log-softmax class predictions.
        """
        x = F.dropout(x, self.dropout, training=self.training)
        for ix, layer in enumerate(self.layers):
            x = layer(x)
            if ix != len(self.layers) - 1:
                x = F.relu(x)
                x = F.dropout(x, self.dropout, training=self.training)

        return F.log_softmax(x, dim=1)
