from graphslim.models import get_model_class
from tqdm import trange

from graphslim.condensation.gcond_base import GCondBase
from graphslim.dataset.utils import save_reduced
from graphslim.evaluation.utils import verbose_time_memory
from graphslim.utils import *
from graphslim.models import *


class GCond(GCondBase):
    """
    "Graph Condensation for Graph Neural Networks" https://cse.msu.edu/~jinwei2/files/GCond.pdf
    """

    def __init__(self, setting, data, args, **kwargs):
        """Initialize GCond and its configuration.

        :param setting: Graph learning setting: ``trans`` for the full graph or ``ind`` for split subgraphs.
        :param data: Graph data containing features, adjacency, labels, and split indices.
        :param args: Configuration namespace containing the options used by this operation.
        :param kwargs: Additional keyword options passed to the underlying implementation.
        """
        super(GCond, self).__init__(setting, data, args, **kwargs)

    @verbose_time_memory
    def reduce(self, data, verbose=True):
        """Optimize synthetic features and adjacency by classwise gradient matching.

        :param data: Graph data containing features, adjacency, labels, and split indices.
        :param verbose: Whether to print progress and diagnostic information. Defaults to ``True``.
        :returns: The input data with synthetic graph attributes populated at evaluation checkpoints.
        """
        args = self.args
        if getattr(args, "gcond_full_class_gradients", False):
            return self._reduce_full_class(data)
        pge = self.pge
        self.feat_syn, labels_syn = to_tensor(
            self.feat_syn, label=data.labels_syn, device=self.device
        )
        if args.setting == "trans":
            features, adj, labels = to_tensor(
                data.feat_full, data.adj_full, label=data.labels_full, device=self.device
            )
        else:
            features, adj, labels = to_tensor(
                data.feat_train, data.adj_train, label=data.labels_train, device=self.device
            )

        # initialization the features
        feat_init = self.init()
        # self.reset_parameters()
        self.feat_syn.data.copy_(feat_init)

        adj = normalize_adj_tensor(adj, sparse=True)

        outer_loop, inner_loop = self.get_loops(args)
        loss_avg = 0
        best_val = 0
        model = get_model_class(args.condense_model)(self.d, args.hidden, data.nclass, args).to(
            self.device
        )
        for it in trange(args.epochs):
            model.initialize()
            model_parameters = list(model.parameters())
            optimizer_model = torch.optim.Adam(model_parameters, lr=args.lr)
            model.train()

            for ol in range(outer_loop):
                adj_syn = pge(self.feat_syn)
                self.adj_syn = normalize_adj_tensor(adj_syn, sparse=False)
                model = self.check_bn(model)
                loss = self.train_class(model, adj, features, labels, labels_syn, args)
                loss_avg += loss.item()

                self.optimizer_feat.zero_grad()
                self.optimizer_pge.zero_grad()
                loss.backward()

                if it % 50 < 10:
                    self.optimizer_pge.step()
                else:
                    self.optimizer_feat.step()

                feat_syn_inner = self.feat_syn.detach()
                adj_syn_inner = pge.inference(feat_syn_inner)
                adj_syn_inner_norm = normalize_adj_tensor(adj_syn_inner, sparse=False)
                feat_syn_inner_norm = feat_syn_inner
                for j in range(inner_loop):
                    optimizer_model.zero_grad()
                    output_syn_inner = model.forward(feat_syn_inner_norm, adj_syn_inner_norm)
                    loss_syn_inner = F.nll_loss(output_syn_inner, labels_syn)
                    loss_syn_inner.backward()
                    optimizer_model.step()

            loss_avg /= data.nclass * outer_loop

            if it in args.checkpoints:
                self.adj_syn = adj_syn_inner
                data.adj_syn, data.feat_syn, data.labels_syn = (
                    self.adj_syn.detach(),
                    self.feat_syn.detach(),
                    labels_syn.detach(),
                )
                best_val = self.intermediate_evaluation(best_val, loss_avg)

        return data

    def _reduce_full_class(self, data):
        """Reduce using exact training-class gradients for the supported one-transform SGC profile.

        Requires no inner optimization, batch normalization, or dropout, and the
        released cosine-gradient distance.

        :param data: Graph data containing features, adjacency, labels, and split indices.
        :returns: The data object populated with the selected synthetic graph.
        """
        from graphslim.condensation.sgdd import (
            full_class_linear_gradients, full_class_gradient_distance,
        )

        args = self.args
        if (args.condense_model != "SGC" or args.ntrans != 1 or args.inner_loop != 0
                or args.dis_metric != "ours" or args.with_bn or args.dropout != 0):
            raise ValueError("Full-class GCond requires single-transform SGC, inner_loop=0, ours distance, no BN/dropout")
        self.feat_syn.data.copy_(self.init())
        source_features = data.feat_full if args.setting == "trans" else data.feat_train
        source_adjacency = data.adj_full if args.setting == "trans" else data.adj_train
        features, adjacency = to_tensor(source_features, source_adjacency, device=self.device)
        propagation = normalize_adj_tensor(adjacency, sparse=True)
        with torch.no_grad():
            real_features = features
            for _ in range(args.nlayers):
                real_features = propagation @ real_features
            if args.setting == "trans":
                real_features = real_features[data.idx_train]
            real_features = real_features.detach()
        real_labels = torch.as_tensor(data.labels_train, device=self.device).long()
        labels_syn = torch.as_tensor(self.labels_syn, device=self.device).long()
        weights = torch.tensor([self.num_class_dict[c] for c in range(data.nclass)], device=self.device).float()
        weights = weights / weights.max()
        label_features = F.one_hot(labels_syn, num_classes=data.nclass).float()
        teacher = SGC(self.d, args.hidden, data.nclass, args).to(self.device)
        best_val = 0
        for epoch in trange(args.epochs):
            teacher.initialize()
            weight, bias = teacher.layers[0].weight.detach(), teacher.layers[0].bias.detach()
            with torch.no_grad():
                real_gradients = full_class_linear_gradients(real_features, real_labels, weight, bias, data.nclass)
            for _ in range(args.outer_loop):
                adjacency_syn = self.pge(self.feat_syn)
                normalized = normalize_adj_tensor(adjacency_syn, sparse=False)
                filtered = self.feat_syn
                for _ in range(args.nlayers):
                    filtered = normalized @ filtered
                gradients = full_class_linear_gradients(filtered, labels_syn, weight, bias, data.nclass)
                loss = full_class_gradient_distance(real_gradients, gradients, weights)
                if args.alpha > 0:
                    loss = loss + args.alpha * regularization(adjacency_syn, label_features)
                if not torch.isfinite(loss):
                    raise FloatingPointError("Full-class GCond loss is not finite")
                self.optimizer_feat.zero_grad(); self.optimizer_pge.zero_grad()
                loss.backward()
                if epoch % 50 < 10:
                    self.optimizer_pge.step()
                else:
                    self.optimizer_feat.step()
            if epoch in args.checkpoints:
                data.adj_syn = self.pge.inference(self.feat_syn.detach())
                data.feat_syn, data.labels_syn = self.feat_syn.detach(), labels_syn
                best_val = self.intermediate_evaluation(best_val, float(loss.detach()))
        return data
