from graphslim.utils import *
import torch_geometric
import math
from numpy.linalg import eigh
from scipy.sparse.linalg import eigsh
from collections import Counter
from torch_geometric.data import Data
from torch_geometric.utils import convert
import networkx as nx


def match_loss(gw_syn, gw_real, args, device):
    """
    Computes the loss between synthetic and real gradients based on the specified distance metric.

    Parameters
    ----------
    gw_syn : list of torch.Tensor
        List of synthetic gradients for different model parameters.
    gw_real : list of torch.Tensor
        List of real gradients for different model parameters.
    args : Namespace
        Arguments object containing hyperparameters for training and model.
    device : torch.device
        Device (CPU or GPU) on which computations are performed.

    Returns
    -------
    torch.Tensor
        The computed distance (loss) between synthetic and real gradients.
    """
    dis = torch.tensor(0.0).to(device)

    if args.dis_metric == "ours":
        for ig in range(len(gw_real)):
            gwr = gw_real[ig]
            gws = gw_syn[ig]
            dis += distance_wb(gwr, gws)

    elif args.dis_metric == "mse":
        gw_real_vec = []
        gw_syn_vec = []
        for ig in range(len(gw_real)):
            gw_real_vec.append(gw_real[ig].reshape((-1)))
            gw_syn_vec.append(gw_syn[ig].reshape((-1)))
        gw_real_vec = torch.cat(gw_real_vec, dim=0)
        gw_syn_vec = torch.cat(gw_syn_vec, dim=0)
        dis = torch.sum((gw_syn_vec - gw_real_vec) ** 2)

    elif args.dis_metric == "cos":
        gw_real_vec = []
        gw_syn_vec = []
        for ig in range(len(gw_real)):
            gw_real_vec.append(gw_real[ig].reshape((-1)))
            gw_syn_vec.append(gw_syn[ig].reshape((-1)))
        gw_real_vec = torch.cat(gw_real_vec, dim=0)
        gw_syn_vec = torch.cat(gw_syn_vec, dim=0)
        dis = 1 - torch.sum(gw_real_vec * gw_syn_vec, dim=-1) / (
            torch.norm(gw_real_vec, dim=-1) * torch.norm(gw_syn_vec, dim=-1) + 0.000001
        )

    else:
        exit("DC error: unknown distance function")

    return dis


def distance_wb(gwr, gws):
    """
    Computes the distance between two tensors representing gradients using cosine similarity.

    Parameters
    ----------
    gwr : torch.Tensor
        The real gradient tensor.
    gws : torch.Tensor
        The synthetic gradient tensor.

    Returns
    -------
    torch.Tensor
        The computed distance between the real and synthetic gradients.
    """
    shape = gwr.shape

    if len(gwr.shape) == 2:
        gwr = gwr.T
        gws = gws.T

    if len(shape) == 4:  # conv, out*in*h*w
        gwr = gwr.reshape(shape[0], shape[1] * shape[2] * shape[3])
        gws = gws.reshape(shape[0], shape[1] * shape[2] * shape[3])
    elif len(shape) == 3:  # layernorm, C*h*w
        gwr = gwr.reshape(shape[0], shape[1] * shape[2])
        gws = gws.reshape(shape[0], shape[1] * shape[2])
    elif len(shape) == 2:  # linear, out*in
        tmp = "do nothing"
    elif len(shape) == 1:  # batchnorm/instancenorm, C; groupnorm x, bias
        gwr = gwr.reshape(1, shape[0])
        gws = gws.reshape(1, shape[0])
        return 0

    dis_weight = torch.sum(
        1
        - torch.sum(gwr * gws, dim=-1)
        / (torch.norm(gwr, dim=-1) * torch.norm(gws, dim=-1) + 0.000001)
    )
    dis = dis_weight
    return dis


# GCSNTK utils
def sub_E(idx, A):
    """
    Generates a sparse adjacency matrix of the subgraph defined by the given indices.

    Parameters
    ----------
    idx : torch.Tensor
        A tensor containing the indices of the nodes that define the subgraph.
    A : torch.Tensor
        The original adjacency matrix of the graph.

    Returns
    -------
    torch.sparse_coo_tensor
        The sparse adjacency matrix of the subgraph.
    """
    n = A.shape[0]
    n_neig = len(idx)
    operator = torch.zeros([n, n_neig])
    operator[idx, range(n_neig)] = 1
    sub_A = torch.matmul(torch.matmul(operator.t(), A), operator)

    ind = torch.where(sub_A != 0)
    inds = torch.cat([ind[0], ind[1]]).reshape(2, len(ind[0]))
    values = torch.ones(len(ind[0]))
    sub_E = torch.sparse_coo_tensor(inds, values, torch.Size([n_neig, n_neig])).to(A.device)

    return sub_E


def update_E(x_s, neig):
    """
    Update the adjacency matrix based on the features of the nodes and the average number of neighbors.

    Parameters
    ----------
    x_s : torch.Tensor
        A tensor containing the feature vectors of the nodes.
    neig : float
        The average number of neighbors each node should have.

    Returns
    -------
    torch.sparse_coo_tensor
        The sparse adjacency matrix based on the updated similarities.
    """
    n = x_s.shape[0]
    K = torch.empty(n, n)
    A = torch.zeros(n * n)

    for i in range(n):
        for j in range(i, n):
            K[i, j] = torch.norm(x_s[i] - x_s[j])
            K[j, i] = K[i, j]

    edge = int(n + torch.round(torch.tensor(neig * n / 2)))
    if (edge % 2) != 0:
        edge += 1
    else:
        pass

    Simil = torch.flatten(K)
    _, indices = torch.sort(Simil)
    A[indices[0:edge]] = 1
    A = A.reshape(n, n)
    ind = torch.where(A == 1)

    ind = torch.cat([ind[0], ind[1]]).reshape(2, edge)
    values = torch.ones(edge)
    E = torch.sparse_coo_tensor(ind, values, torch.Size([n, n])).to(x_s.device)

    return E


# utils for GCSNTK
def normalize_data(data):
    """
    Normalize the input data using mean and standard deviation.

    Parameters
    ----------
    data : torch.Tensor
        The data to be normalized. Each column represents a feature, and normalization is applied to each feature independently.

    Returns
    -------
    torch.Tensor
        The normalized data where each feature has zero mean and unit variance.
    """
    mean = data.mean(dim=0)
    std = data.std(dim=0)
    std[std == 0] = 1
    normalized_data = (data - mean) / std
    return normalized_data


def GCF(adj, x, k=1):
    """
    Apply Graph Convolution Filter (GCF) to features using the adjacency matrix.

    Parameters
    ----------
    adj : torch.Tensor
        Adjacency matrix of the graph. It must include self-loops. Shape: (N, N), where N is the number of nodes.

    x : torch.Tensor
        Node features. Shape: (N, F), where F is the number of features for each node.

    k : int, optional
        Number of hops (or layers) to apply the filter. Default is 1.

    Returns
    -------
    torch.Tensor
        Filtered features after applying the graph convolution. Shape: (N, F).
    """
    D = torch.sum(adj, dim=1)
    D = torch.pow(D, -0.5)
    D = torch.diag(D)

    filter = torch.matmul(torch.matmul(D, adj), D)
    for i in range(k):
        x = torch.matmul(filter, x)
    return x


# geom
def neighborhood_difficulty_measurer(data, adj, label):
    """
    Measure the difficulty of neighborhoods in the graph based on the label distribution.

    Parameters
    ----------
    data : Data
        PyG Data object containing node features and labels.

    adj : torch.Tensor
        Sparse adjacency matrix of the graph. The shape is (N, N) where N is the number of nodes.

    label : torch.Tensor
        Tensor containing the label of each node. Shape: (N,)

    Returns
    -------
    torch.Tensor
        Difficulty scores for each node. Higher scores indicate more difficult neighborhoods.
    """
    edge_index = adj.coalesce().indices()
    edge_value = adj.coalesce().values()

    neighbor_label, _ = torch_geometric.utils.add_self_loops(
        edge_index
    )  # [[1, 1, 1, 1],[2, 3, 4, 5]]

    neighbor_label[1] = label[neighbor_label[1]]  # [[1, 1, 1, 1],[40, 20, 19, 21]]

    neighbor_label = torch.transpose(neighbor_label, 0, 1)  # [[1, 40], [1, 20], [1, 19], [1, 21]]

    index, count = torch.unique(neighbor_label, sorted=True, return_counts=True, dim=0)

    neighbor_class = torch.sparse_coo_tensor(index.T, count)
    neighbor_class = neighbor_class.to_dense().float()

    neighbor_class = neighbor_class[data.idx_train]
    neighbor_class = F.normalize(neighbor_class, 1.0, 1)
    neighbor_entropy = (
        -1 * neighbor_class * torch.log(neighbor_class + torch.exp(torch.tensor(-20)))
    )  # 防止log里面是0出现异常
    local_difficulty = neighbor_entropy.sum(1)

    return local_difficulty


def difficulty_measurer(data, adj, label):
    """
    Measure the difficulty of nodes in the graph based on their neighborhood label distribution.

    Parameters
    ----------
    data : Data
        PyG Data object containing node features and labels.

    adj : torch.Tensor
        Sparse adjacency matrix of the graph. The shape is (N, N) where N is the number of nodes.

    label : torch.Tensor
        Tensor containing the label of each node. Shape: (N,)

    Returns
    -------
    torch.Tensor
        Difficulty scores for each node. Higher scores indicate more difficult nodes.
    """
    local_difficulty = neighborhood_difficulty_measurer(data, adj, label)
    # global_difficulty = feature_difficulty_measurer(data, label, embedding)
    node_difficulty = local_difficulty
    return node_difficulty


def sort_training_nodes(data, adj, label):
    """
    Sort training nodes based on their difficulty measured by neighborhood label distribution.

    Parameters
    ----------
    data : Data
        PyG Data object containing node features and labels.

    adj : torch.Tensor
        Sparse adjacency matrix of the graph (shape: N x N) with self-loops.

    label : torch.Tensor
        Tensor containing the label of each node (shape: N,).

    Returns
    -------
    numpy.ndarray
        Indices of the training nodes sorted by their difficulty, from easiest to hardest.
    """
    node_difficulty = difficulty_measurer(data, adj, label)
    _, indices = torch.sort(node_difficulty)
    indices = indices.cpu().numpy()
    sorted_trainset = data.idx_train[indices]
    return sorted_trainset


def neighborhood_difficulty_measurer_in(data, adj, label):
    """
    Measure the difficulty of each node in a graph based on the entropy of neighbor labels.

    Parameters
    ----------
    data : Data
        PyG Data object containing node features and labels.

    adj : torch.Tensor
        Sparse adjacency matrix of the graph (shape: N x N) with self-loops.

    label : torch.Tensor
        Tensor containing the label of each node (shape: N,).

    Returns
    -------
    torch.Tensor
        Tensor of local difficulty scores for each node.
    """
    edge_index = adj.coalesce().indices()
    edge_value = adj.coalesce().values()

    neighbor_label, _ = torch_geometric.utils.add_self_loops(
        edge_index
    )  # [[1, 1, 1, 1],[2, 3, 4, 5]]

    neighbor_label[1] = label[neighbor_label[1]]  # [[1, 1, 1, 1],[40, 20, 19, 21]]

    neighbor_label = torch.transpose(neighbor_label, 0, 1)  # [[1, 40], [1, 20], [1, 19], [1, 21]]

    index, count = torch.unique(neighbor_label, sorted=True, return_counts=True, dim=0)

    neighbor_class = torch.sparse_coo_tensor(index.T, count)
    neighbor_class = neighbor_class.to_dense().float()

    neighbor_class = F.normalize(neighbor_class, 1.0, 1)
    neighbor_entropy = (
        -1 * neighbor_class * torch.log(neighbor_class + torch.exp(torch.tensor(-20)))
    )  # 防止log里面是0出现异常
    local_difficulty = neighbor_entropy.sum(1)

    return local_difficulty


def difficulty_measurer_in(data, adj, label):
    """
    Measure the difficulty of each node in a graph based on local entropy of neighbor labels.

    Parameters
    ----------
    data : Data
        PyG Data object containing node features and labels.

    adj : torch.Tensor
        Sparse adjacency matrix of the graph (shape: N x N) with self-loops.

    label : torch.Tensor
        Tensor containing the label of each node (shape: N,).

    Returns
    -------
    torch.Tensor
        Tensor of local difficulty scores for each node.
    """
    local_difficulty = neighborhood_difficulty_measurer_in(data, adj, label)
    # global_difficulty = feature_difficulty_measurer(data, label, embedding)
    node_difficulty = local_difficulty
    return node_difficulty


def sort_training_nodes_in(data, adj, label):
    """
    Sort training nodes based on their difficulty scores in ascending order.

    Parameters
    ----------
    data : Data
        PyG Data object containing node features and labels.

    adj : torch.Tensor
        Sparse adjacency matrix of the graph (shape: N x N) with self-loops.

    label : torch.Tensor
        Tensor containing the label of each node (shape: N,).

    Returns
    -------
    numpy.ndarray
        Indices of training nodes sorted by difficulty scores.
    """
    node_difficulty = difficulty_measurer_in(data, adj, label)
    _, indices = torch.sort(node_difficulty)
    indices = indices.cpu().numpy()
    return indices


def training_scheduler(lam, t, T, scheduler="geom"):
    """
    Adjust the value of a parameter based on the chosen scheduling strategy.

    Parameters
    ----------
    lam : float
        The initial value or a baseline value for the parameter (0 <= lam <= 1).

    t : int
        The current training iteration or epoch.

    T : int
        The total number of training iterations or epochs.

    scheduler : str, optional
        The type of scheduling strategy to use. Options are 'linear', 'root', or 'geom'.
        Default is 'geom'.

    Returns
    -------
    float
        The adjusted value of the parameter at iteration `t` based on the scheduling strategy.
    """
    if scheduler == "linear":
        return min(1, lam + (1 - lam) * t / T)
    elif scheduler == "root":
        return min(1, math.sqrt(lam**2 + (1 - lam**2) * t / T))
    elif scheduler == "geom":
        return min(1, 2 ** (math.log2(lam) - math.log2(lam) * t / T))


def get_largest_cc(adj, num_nodes, data_name):
    """Extract the largest undirected connected component and its normalized adjacency.

    :param adj: Graph adjacency; rows and columns refer to the same node ordering as the features.
    :param num_nodes: Number of nodes in the graph.
    :param data_name: Dataset name retained for compatibility with the component helper interface.
    :returns: Tuple ``(original_node_ids, normalized_adjacency, raw_adjacency)``.
    """
    mx = (adj).tocoo()
    edge_index = torch.LongTensor(np.vstack([mx.row, mx.col]))
    data = Data(edge_index=edge_index, num_nodes=num_nodes)
    nx_graph = convert.to_networkx(data, to_undirected=True)

    largest_cc = max(nx.connected_components(nx_graph), key=len)
    idx_lcc = sorted(largest_cc)
    largest_cc_graph = nx_graph.subgraph(largest_cc)

    if len(idx_lcc) == num_nodes:
        adj_lcc = adj
        adj_norm_lcc = gcn_normalize_adj(adj_lcc)
    else:
        adj_lcc = nx.to_scipy_sparse_array(largest_cc_graph, nodelist=idx_lcc)
        adj_norm_lcc = gcn_normalize_adj(adj_lcc)

    return idx_lcc, adj_norm_lcc, adj_lcc


def get_syn_eigen(real_eigenvals, real_eigenvecs, eigen_k, ratio, step=1):
    """Select low- and high-frequency eigenpairs with the requested ratio and stride.

    :param real_eigenvals: Eigenvalues ordered consistently with the eigenvector columns.
    :param real_eigenvecs: Eigenvector matrix; columns correspond to eigenvalues unless stated otherwise.
    :param eigen_k: Number of spectral components or propagation steps to use.
    :param ratio: Fraction of selected eigenpairs taken from the low end of the spectrum.
    :param step: Stride between selected eigenpairs. Defaults to ``1``.
    :returns: Tuple ``(selected_eigenvalues, selected_eigenvectors)``.
    """
    k1 = math.ceil(eigen_k * ratio)
    k2 = eigen_k - k1
    print("k1:", k1, ",", "k2:", k2)
    k1_end = (k1 - 1) * step + 1
    eigen_sum = real_eigenvals.shape[0]
    k2_end = eigen_sum - (k2 - 1) * step - 1
    k1_list = range(0, k1_end, step)
    k2_list = range(k2_end, eigen_sum, step)
    eigenvals = torch.cat([real_eigenvals[k1_list], real_eigenvals[k2_list]])
    eigenvecs = torch.cat(
        [real_eigenvecs[:, k1_list], real_eigenvecs[:, k2_list]],
        dim=1,
    )

    return eigenvals, eigenvecs


def get_subspace_embed(eigenvecs, x):
    """Project node features onto the selected eigenbasis and each individual eigenspace.

    :param eigenvecs: Eigenvector matrix; columns correspond to eigenvalues unless stated otherwise.
    :param x: Node feature matrix with one row per node.
    :returns: Tuple ``(spectral_features, per_eigenvector_node_embeddings)``.
    """
    x_trans = eigenvecs.T @ x  # kd
    u_unsqueeze = (eigenvecs.T).unsqueeze(2)  # kn1
    x_trans_unsqueeze = x_trans.unsqueeze(1)  # k1d
    sub_embed = torch.bmm(u_unsqueeze, x_trans_unsqueeze)  # kn1 @ k1d = knd
    return x_trans, sub_embed


def get_subspace_covariance_matrix(eigenvecs, x):
    """Form a feature outer product for each normalized spectral feature row.

    :param eigenvecs: Eigenvector matrix; columns correspond to eigenvalues unless stated otherwise.
    :param x: Node feature matrix with one row per node.
    :returns: Tensor of shape ``(num_eigenvectors, feature_dim, feature_dim)``.
    """
    x_trans = eigenvecs.T @ x  # kd
    x_trans = F.normalize(input=x_trans, p=2, dim=1)
    x_trans_unsqueeze = x_trans.unsqueeze(1)  # k1d
    co_matrix = torch.bmm(x_trans_unsqueeze.permute(0, 2, 1), x_trans_unsqueeze)  # kd1 @ k1d = kdd
    return co_matrix


def get_embed_sum(eigenvals, eigenvecs, x):
    """Filter features with spectral weights ``1 - eigenvalue`` and reconstruct node embeddings.

    :param eigenvals: Eigenvalues ordered consistently with the eigenvector columns.
    :param eigenvecs: Eigenvector matrix; columns correspond to eigenvalues unless stated otherwise.
    :param x: Node feature matrix with one row per node.
    :returns: Node embedding matrix with the same shape as the input features.
    """
    x_trans = eigenvecs.T @ x  # kd
    x_trans = torch.diag(1 - eigenvals) @ x_trans  # kd
    embed_sum = eigenvecs @ x_trans  # nk @ kd = nd
    return embed_sum


def get_embed_mean(embed_sum, label, class_matrix=None):
    """Compute normalized class means of node embeddings while keeping empty classes zero.

    :param embed_sum: Filtered node embedding matrix.
    :param label: Node labels in the same node ordering as the corresponding features.
    :param class_matrix: Optional class-by-node membership matrix; otherwise built from the labels. Defaults to ``None``.
    :returns: Class-by-feature tensor of L2-normalized mean embeddings.
    """
    if class_matrix is None:
        class_matrix = F.one_hot(label).float().T  # cn
    embed_sum = class_matrix @ embed_sum  # cd
    # A connected component can have no training example for an interior class.
    # Keep its row zero; callers can select observed classes explicitly.
    mean_weight = class_matrix.sum(1).clamp_min(1).reciprocal().unsqueeze(-1)  # c1
    embed_mean = mean_weight * embed_sum
    embed_mean = F.normalize(input=embed_mean, p=2, dim=1)
    return embed_mean


# Graphs too large for a dense eigendecomposition: GDEM keeps the 1000 smallest and
# 1000 largest Laplacian eigenpairs, as in the authors' preprocessing.
LARGE_EIGEN_DATASETS = ("ogbn-arxiv", "flickr", "reddit", "yelp", "twitch-gamer")


def get_eigh(laplacian_matrix, data_name, save=True, root="./data"):
    """Eigendecomposition of a Laplacian, cached under ``root/data_name`` when ``save``.

    ``root`` must match the ``load_path`` later passed to :func:`load_eigen`.
    Uncached calls (``save=False``) neither read nor write files.
    """
    dir = os.path.join(root, data_name)
    if save and not os.path.isdir(dir):
        os.makedirs(dir)

    val_file_name = "eigenvalues.npy"
    vec_file_name = "eigenvectors.npy"

    eigvals_path = os.path.join(dir, val_file_name)
    eigvecs_path = os.path.join(dir, vec_file_name)

    if save and os.path.exists(eigvals_path) and os.path.exists(eigvecs_path):
        eigenvalues = np.load(eigvals_path)
        eigenvectors = np.load(eigvecs_path)
    else:
        if data_name in LARGE_EIGEN_DATASETS and laplacian_matrix.shape[0] > 2000:
            eigenvalues, eigenvectors = eigsh(A=laplacian_matrix, k=1000, which="SA", tol=1e-5)
        else:
            if sp.issparse(laplacian_matrix):
                laplacian_matrix = laplacian_matrix.todense()
            eigenvalues, eigenvectors = eigh(laplacian_matrix)

        if save:
            np.save(eigvals_path, eigenvalues)
            np.save(eigvecs_path, eigenvectors)

    if data_name in LARGE_EIGEN_DATASETS:
        val_file_name = "eigenvalues_la.npy"
        vec_file_name = "eigenvectors_la.npy"
        eigvals_path = os.path.join(dir, val_file_name)
        eigvecs_path = os.path.join(dir, vec_file_name)

        if save and os.path.exists(eigvals_path) and os.path.exists(eigvecs_path):
            eigenvalues_la = np.load(eigvals_path)
            eigenvectors_la = np.load(eigvecs_path)
        else:
            if laplacian_matrix.shape[0] > 2000:
                eigenvalues_la, eigenvectors_la = eigsh(
                    A=laplacian_matrix, k=1000, which="LA", tol=1e-5
                )
            else:
                # The complete small-graph spectrum is already in the first
                # files. Keep the cache format without duplicating eigenpairs.
                eigenvalues_la = np.empty(0)
                eigenvectors_la = np.empty((laplacian_matrix.shape[0], 0))
            if save:
                np.save(eigvals_path, eigenvalues_la)
                np.save(eigvecs_path, eigenvectors_la)

        eigenvalues = np.hstack([eigenvalues, eigenvalues_la])
        eigenvectors = np.hstack([eigenvectors, eigenvectors_la])

    idx = np.argsort(eigenvalues)
    eigenvalues = eigenvalues[idx[:]]
    eigenvectors = eigenvectors[:, idx[:]]

    return eigenvalues, eigenvectors


def load_eigen(dataset, load_path):
    """Load cached eigenpairs, merge large-dataset spectral ranges, and sort by eigenvalue.

    :param dataset: Dataset name or dataset collection, as required by this operation.
    :param load_path: Filesystem location used by this operation.
    :returns: Tuple of NumPy arrays ``(eigenvalues, eigenvectors)``.
    """
    dir = os.path.join(load_path, dataset)
    val_file_name = "eigenvalues.npy"
    vec_file_name = "eigenvectors.npy"

    eigvals_path = os.path.join(dir, val_file_name)
    eigvecs_path = os.path.join(dir, vec_file_name)
    eigenvalues = np.load(eigvals_path)
    eigenvectors = np.load(eigvecs_path)

    if dataset in LARGE_EIGEN_DATASETS:
        val_file_name = "eigenvalues_la.npy"
        vec_file_name = "eigenvectors_la.npy"
        eigvals_path = os.path.join(dir, val_file_name)
        eigvecs_path = os.path.join(dir, vec_file_name)
        eigenvalues_la = np.load(eigvals_path)
        eigenvectors_la = np.load(eigvecs_path)

        eigenvalues = np.hstack([eigenvalues, eigenvalues_la])
        eigenvectors = np.hstack([eigenvectors, eigenvectors_la])

    idx = np.argsort(eigenvalues)
    eigenvalues = eigenvalues[idx[:]]
    eigenvectors = eigenvectors[:, idx[:]]

    return eigenvalues, eigenvectors


def get_train_lcc(idx_lcc, idx_train, y_full, num_nodes, num_classes):
    # Compare plain integers: set operations on tensor elements never match.
    """Map only observed training nodes into the largest connected component.

    Validation and test labels are never used to fill missing training classes.

    :param idx_lcc: Original node IDs belonging to the largest connected component.
    :param idx_train: Original node IDs belonging to the training split.
    :param y_full: Full-graph labels; retained for compatibility and not used to infer missing training labels.
    :param num_nodes: Number of nodes in the graph.
    :param num_classes: Number of output classes.
    :returns: Tuple ``(original_training_node_ids, component_local_node_ids)``.
    """
    if hasattr(idx_train, "cpu"):
        idx_train = idx_train.cpu().numpy()
    idx_train = [int(i) for i in idx_train]
    idx_lcc = [int(i) for i in idx_lcc]
    local_index = {node: i for i, node in enumerate(idx_lcc)}
    idx_train_lcc = [node for node in idx_train if node in local_index]
    # Validation/test labels must never fill missing classes in a component.
    idx_map = [local_index[node] for node in idx_train_lcc]

    return idx_train_lcc, idx_map
