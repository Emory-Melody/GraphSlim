from copy import deepcopy

import torch.nn as nn
import torch.optim as optim
from torch_geometric.nn.resolver import activation_resolver

from graphslim.utils import *


class BaseGNN(nn.Module):
    """Shared graph model training, validation selection, and prediction interface.
    """
    def __init__(self, nfeat, nhid, nclass, args, mode):

        """Initialize BaseGNN and its configuration.

        :param nfeat: Number of input features per node.
        :param nhid: Hidden representation width.
        :param nclass: Number of output classes.
        :param args: Configuration namespace containing the options used by this operation.
        :param mode: Model configuration mode; selects training or evaluation settings.
        """
        super(BaseGNN, self).__init__()
        self.args = args
        self.with_bn = args.with_bn
        activation = getattr(args, "activation", "relu")
        if isinstance(activation, str) and activation.lower() in ("none", "linear"):
            activation = None
        self.activation = activation_resolver(activation)
        # Retain the legacy switch for callers that explicitly disable activation.
        self.with_relu = self.activation is not None
        self.with_bias = True
        self.weight_decay = args.weight_decay
        self.lr = args.lr
        self.dropout = args.dropout
        self.alpha = args.alpha
        self.nlayers = args.nlayers
        self.ntrans = args.ntrans
        self.device = args.device
        self.layers = nn.ModuleList([])
        self.loss = None

        if mode == "eval":
            self.dropout = 0
            self.weight_decay = 5e-4
        if mode == "attack":
            self.loss = F.nll_loss

        self.output = None
        self.best_model = None
        self.best_output = None
        self.adj_norm = None
        self.features = None
        self.multi_label = args.multi_label
        self.float_label = None
        # self.metric = accuracy if args.metric == 'accuracy' else f1_macro
        self.metric = args.metric

    def initialize(self):
        """Reset model layers and enabled batch normalization statistics.
        """
        for layer in self.layers:
            layer.reset_parameters()
        if self.with_bn:
            for bn in self.bns:
                bn.reset_parameters()

    def forward(self, x, adj, output_layer_features=False):

        """Compute node predictions from features and one adjacency or a list of layer adjacencies.

        :param x: Node feature matrix with one row per node.
        :param adj: Graph adjacency; rows and columns refer to the same node ordering as the features.
        :param output_layer_features: Whether to also return intermediate layer features with the predictions. Defaults to ``False``.
        :returns: Class log probabilities, sigmoid probabilities for multilabel tasks, or ``(layer_features, log_probabilities)`` when requested.
        """
        if self.__class__.__name__ == "GCN" and getattr(self.args, "gcn_input_dropout", False):
            x = F.dropout(x, self.dropout, training=self.training)
        if isinstance(adj, list):
            for i, layer in enumerate(self.layers):
                x = layer(x, adj[i])
                if i != self.nlayers - 1:
                    x = self.bns[i](x) if self.with_bn else x
                    if self.with_relu:
                        x = self.activation(x)
                    x = F.dropout(x, self.dropout, training=self.training)
        else:
            feat_list = []
            for ix, layer in enumerate(self.layers):
                x = layer(x, adj)
                if ix != self.nlayers - 1:
                    x = self.bns[ix](x) if self.with_bn else x
                    if self.with_relu:
                        x = self.activation(x)
                    x = F.dropout(x, self.dropout, training=self.training)
                if output_layer_features and ix < self.nlayers:
                    feat_list.append(x.reshape(-1, x.shape[-1]))

        x = x.view(-1, x.shape[-1])
        if self.multi_label:
            return torch.sigmoid(x)
        if output_layer_features:
            return feat_list, F.log_softmax(x, dim=1)
        else:
            return F.log_softmax(x, dim=1)

    def fit_with_val(
        self,
        data,
        train_iters=600,
        verbose=False,
        normadj=True,
        setting="trans",
        reduced=False,
        final_output=False,
        best_val=None,
        **kwargs,
    ):
        """Train on the original or synthetic graph and select weights using validation performance.

        :param data: Graph data containing features, adjacency, labels, and split indices.
        :param train_iters: Number of training iterations. Defaults to ``600``.
        :param verbose: Whether to print progress and diagnostic information. Defaults to ``False``.
        :param normadj: Whether to normalize the adjacency before use. Defaults to ``True``.
        :param setting: Graph learning setting: ``trans`` for the full graph or ``ind`` for split subgraphs. Defaults to ``'trans'``.
        :param reduced: Whether to use the synthetic graph instead of the original training graph. Defaults to ``False``.
        :param final_output: Whether to leave the final-iteration weights in place and return early. Defaults to ``False``.
        :param best_val: Initial best validation score used when selecting model weights. Defaults to ``None``.
        :param kwargs: Additional keyword options passed to the underlying implementation.
        :returns: Best validation score as a float; ``final_output=True`` returns ``None`` before restoring validation-selected weights.
        """
        args = self.args

        self.initialize()
        cache = getattr(self, "_evaluation_graph_cache", None)
        prepared_training = (
            cache is not None
            and not reduced
            and self.__class__.__name__ != "GAT"
            and args.method not in ("simgc", "msgc")
        )
        # data for training
        if prepared_training:
            source_features = data.feat_full if setting == "trans" else data.feat_train
            source_adjacency = data.adj_full if setting == "trans" else data.adj_train
            features, adj = cache.get(source_features, source_adjacency, normalize=True)
            labels, labels_val = to_tensor(
                label=data.labels_train, label2=data.labels_val, device=self.device
            )
        elif reduced:
            adj, features, labels, labels_val = to_tensor(
                data.adj_syn,
                data.feat_syn,
                data.labels_syn,
                label2=data.labels_val,
                device=self.device,
            )

        elif setting == "trans":
            adj, features, labels, labels_val = to_tensor(
                data.adj_full,
                data.feat_full,
                label=data.labels_train,
                label2=data.labels_val,
                device=self.device,
            )
        else:
            adj, features, labels, labels_val = to_tensor(
                data.adj_train,
                data.feat_train,
                label=data.labels_train,
                label2=data.labels_val,
                device=self.device,
            )
        if prepared_training:
            pass
        elif reduced and (
            (args.method == "vng" and getattr(args, "vng_normalized_operator", False))
            or (args.method == "gdem" and getattr(args, "gdem_normalized_operator", False))
        ):
            # This checkpoint already stores the fitted propagation operator.
            pass
        elif self.__class__.__name__ == "GAT":
            # gat must use SparseTensor
            if len(adj.shape) == 3:
                adj = [normalize_adj_tensor(a.to_sparse(), sparse=True) for a in adj]
            else:
                if not is_sparse_tensor(adj):
                    adj = adj.to_sparse()
                adj = normalize_adj_tensor(adj, sparse=True)

        # SparseTensor synthetic graph only used in graphsage, msgc and simgc
        elif self.__class__.__name__ == "GraphSage" and args.method == "msgc":
            adj = adj
        elif args.method == "simgc":
            adj = normalize_adj_tensor(adj, sparse=True)
        else:
            adj = normalize_adj_tensor(adj, sparse=is_sparse_tensor(adj))

        if self.loss is None:
            if args.method == "geom" and args.soft_label:
                self.loss = torch.nn.KLDivLoss(reduction="batchmean", log_target=True)
            elif data.nclass == 1:
                self.loss = torch.nn.BCELoss()
            elif len(labels.shape) == 2:
                if args.eval_loss == "MSE":
                    # GCSNTK/GCGP regress probability scores in their released
                    # downstream models; forward() here returns log-probabilities.
                    self.loss = (
                        (lambda output, target: F.mse_loss(output.exp(), target))
                        if args.method in ("gcgp", "gcsntk")
                        else torch.nn.MSELoss()
                    )
                elif args.eval_loss == "KLD":
                    self.loss = torch.nn.KLDivLoss(reduction="batchmean", log_target=True)
                else:
                    raise NotImplementedError
                self.weight_decay = args.eval_wd
            else:
                labels = to_tensor(label=labels, device=self.device)
                self.loss = F.nll_loss
        else:
            labels = to_tensor(label=labels, device=self.device)

        if verbose:
            print("=== training ===")

        if best_val is None:
            best_acc_val = 0
        else:
            best_acc_val = best_val
        if setting == "ind":
            feat_full, adj_full = data.feat_val, data.adj_val
        else:
            feat_full, adj_full = data.feat_full, data.adj_full
        if cache is not None:
            feat_full, adj_full = cache.get(feat_full, adj_full, normalize=normadj)
        else:
            feat_full, adj_full = to_tensor(feat_full, adj_full, device=self.device)
            if normadj:
                adj_full = normalize_adj_tensor(adj_full, sparse=is_sparse_tensor(adj_full))

        optimizer = optim.Adam(self.parameters(), lr=self.lr, weight_decay=self.weight_decay)
        val_interval = getattr(args, "val_interval", 1)
        if val_interval < 1:
            raise ValueError("val_interval must be positive")

        training_index = None
        if features.shape[0] != labels.shape[0]:
            training_index = data.idx_train

        def training_loss():
            """Compute predictions and the training objective on the selected graph.

            :returns: Tuple ``(node_predictions, scalar_training_loss)``.
            """
            output = self.forward(features, adj)
            loss = self.loss(
                output if output.shape[0] == labels.shape[0] else output[training_index], labels
            )
            return output, loss

        self.train()
        for i in range(train_iters):
            self.train()
            if i == train_iters // 2 and self.lr > 0.001 and getattr(args, "lr_decay", True):
                optimizer = optim.Adam(
                    self.parameters(), lr=self.lr * 0.1, weight_decay=self.weight_decay
                )

            optimizer.zero_grad()
            output, loss_train = training_loss()
            loss_train.backward()
            optimizer.step()

            if verbose and i % 100 == 0:
                print("Epoch {}, training loss: {}".format(i, loss_train.item()))
                acc_train = accuracy(
                    output if output.shape[0] == labels.shape[0] else output[data.idx_train], labels
                )
                print("Epoch {}, training acc: {}".format(i, acc_train))

            if i % val_interval != 0:
                continue
            with torch.no_grad():
                self.eval()
                output = self.forward(feat_full, adj_full)

                acc_val = self.metric(
                    output if output.shape[0] == labels_val.shape[0] else output[data.idx_val],
                    labels_val,
                )

                if acc_val > best_acc_val:
                    best_acc_val = acc_val
                    # self.output = output
                    weights = deepcopy(self.state_dict())
        if final_output:
            return
        if verbose:
            print("=== picking the best model according to the performance on validation ===")
        try:
            self.load_state_dict(weights)
        except:
            pass
        return float(best_acc_val)

    @torch.no_grad()
    def test(self, data, setting="trans", verbose=False):
        """Evaluate the configured classification metric on the test graph or test nodes.

        :param data: Graph data containing features, adjacency, labels, and split indices.
        :param setting: Graph learning setting: ``trans`` for the full graph or ``ind`` for split subgraphs. Defaults to ``'trans'``.
        :param verbose: Whether to print progress and diagnostic information. Defaults to ``False``.
        :returns: Test metric as a Python float; verbose mode also prints the test loss.
        """
        self.eval()
        idx_test = data.idx_test
        labels_test = torch.LongTensor(data.labels_test).to(self.device)
        # whether condensed or not, use the raw graph to test

        if setting == "ind":
            output = self.predict(data.feat_test, data.adj_test)
            loss_test = F.nll_loss(output, labels_test)
            acc_test = self.metric(output, labels_test)
        else:
            output = self.predict(data.feat_full, data.adj_full)
            loss_test = F.nll_loss(output[idx_test], labels_test)
            acc_test = self.metric(output[idx_test], labels_test)

        if verbose:
            print(
                "Test set results:",
                "loss= {:.4f}".format(loss_test.item()),
                "accuracy= {:.4f}".format(float(acc_test)),
            )
        return float(acc_test)

    @torch.no_grad()
    def predict(self, features=None, adj=None, normadj=True, output_layer_features=False):

        """Switch to evaluation mode, prepare graph tensors, and compute node predictions.

        :param features: Node feature matrix with one row per node. Defaults to ``None``.
        :param adj: Graph adjacency; rows and columns refer to the same node ordering as the features. Defaults to ``None``.
        :param normadj: Whether to normalize the adjacency before use. Defaults to ``True``.
        :param output_layer_features: Whether to also return intermediate layer features with the predictions. Defaults to ``False``.
        :returns: Output of ``forward``, including intermediate features when requested.
        """
        self.eval()
        cache = getattr(self, "_evaluation_graph_cache", None)
        if cache is not None:
            features, adj = cache.get(features, adj, normalize=normadj)
        else:
            features, adj = to_tensor(features, adj, device=self.device)
            if normadj:
                adj = normalize_adj_tensor(adj, sparse=is_sparse_tensor(adj))

        return self.forward(features, adj, output_layer_features=output_layer_features)
